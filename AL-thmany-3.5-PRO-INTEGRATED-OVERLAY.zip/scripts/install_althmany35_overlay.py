#!/usr/bin/env python3
from pathlib import Path
import shutil, sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
BUNDLE = Path(__file__).resolve().parent.parent
PAYLOAD = BUNDLE / "payload"


def die(msg):
    raise SystemExit(f"ERROR: {msg}")


def replace_once(path: Path, old: str, new: str, label: str):
    text = path.read_text(encoding="utf-8")
    if new in text:
        print(f"SKIP {label}: already applied")
        return
    if old not in text:
        die(f"{label}: expected source pattern not found in {path}")
    path.write_text(text.replace(old, new, 1), encoding="utf-8")
    print(f"PATCH {label}")


def copy_payload():
    if not PAYLOAD.exists():
        die("payload directory missing")
    for src in PAYLOAD.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(PAYLOAD)
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        print(f"COPY {rel}")


def patch_main_activity():
    p = ROOT / "app/src/main/java/com/althmany/extractor/MainActivity.kt"
    replace_once(
        p,
        """                    onSpeed = viewModel::setScanSpeed,\n                    onAttempts = viewModel::setScanMaxAttempts,""",
        """                    onSpeed = viewModel::setScanSpeed,\n                    onScope = viewModel::setScanScope,\n                    onAttempts = viewModel::setScanMaxAttempts,""",
        "MainActivity scan scope callback",
    )


def patch_workspace():
    p = ROOT / "app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt"
    replace_once(
        p,
        "import com.althmany.extractor.data.*\n",
        "import com.althmany.extractor.data.*\nimport com.althmany.groupmanager.BuildConfig\n",
        "Workspace BuildConfig import",
    )
    replace_once(
        p,
        '                    "Al-othmany Sender 3.4.1",',
        '                    "Al-othmany Sender ${BuildConfig.VERSION_NAME}",',
        "Workspace dynamic version",
    )
    replace_once(
        p,
        """    val filtered = if (query.isBlank()) groups else groups.filter { it.name.contains(query, true) }\n    val running = extractionBusy(engine)\n    val paused = engine.status == EngineStatus.PAUSED\n""",
        """    val filtered = if (query.isBlank()) groups else groups.filter { it.name.contains(query, true) }\n    val running = extractionBusy(engine)\n    val paused = engine.status == EngineStatus.PAUSED\n    val targetPackage = engine.selectedWhatsAppPackage.orEmpty()\n    val registry = remember(groups, targetPackage) {\n        GroupRegistryPolicy.assess(\n            rows = groups.map {\n                GroupRegistryRow(\n                    name = it.name,\n                    whatsappPackage = it.whatsappPackage,\n                    lastSyncedAt = it.lastSyncedAt,\n                    syncGeneration = it.syncGeneration,\n                    stale = it.stale,\n                    discovered = it.discovered\n                )\n            },\n            targetPackage = targetPackage,\n            nowMs = System.currentTimeMillis()\n        )\n    }\n    val hasExtractionTargets = groups.any { it.selected && !it.stale && it.active } ||\n        groups.any { it.discovered && !it.stale && it.active && (it.whatsappPackage.isBlank() || it.whatsappPackage == targetPackage) }\n""",
        "Extraction registry state",
    )
    replace_once(
        p,
        """        item { UnifiedRuntimeStatusStrip(runtime) }\n        item {\n            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {""",
        """        item { UnifiedRuntimeStatusStrip(runtime) }\n        item {\n            VCard(accent = if (registry.canSkipSync) VGreen.copy(alpha = .65f) else VOrange.copy(alpha = .65f)) {\n                VTitle("حالة سجل القروبات", Icons.Default.Sync, if (registry.canSkipSync) VGreen else VOrange)\n                Spacer(Modifier.height(6.dp))\n                Text(\n                    if (registry.canSkipSync)\n                        "السجل حديث ومكتمل: ${registry.activeGroupCount} قروب. يمكنك البدء مباشرة وسيتم تخطي المزامنة بأمان."\n                    else\n                        "المزامنة مطلوبة: ${registry.detailAr}",\n                    color = VText, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End\n                )\n            }\n        }\n        item {\n            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {""",
        "Extraction registry card",
    )
    # Two start enablement sites: main button and VControls.
    text = p.read_text(encoding="utf-8")
    text = text.replace(
        "enabled = engine.selectedWhatsAppPackage != null && groups.any { it.selected } && !running,",
        "enabled = engine.selectedWhatsAppPackage != null && hasExtractionTargets && !running,",
        1,
    )
    text = text.replace(
        'Text("مزامنة القروبات", color = VText, fontSize = 13.sp)',
        'Text(if (registry.canSkipSync) "تحديث المزامنة" else "مزامنة القروبات", color = VText, fontSize = 13.sp)',
        1,
    )
    text = text.replace(
        'item { VChoice("غير المقروءة", false, VPurple, Modifier.width(108.dp)) { onPreset(GroupSelectionPreset.UNREAD) } }\n                    item { VChoice("النشطة", false, VGreen, Modifier.width(108.dp)) { onPreset(GroupSelectionPreset.ACTIVE) } }',
        'item { VChoice("غير المقروءة", false, VPurple, Modifier.width(108.dp)) { onPreset(GroupSelectionPreset.UNREAD) } }\n                    item { VChoice("المقروءة", false, VBlue, Modifier.width(108.dp)) { onPreset(GroupSelectionPreset.READ) } }\n                    item { VChoice("النشطة", false, VGreen, Modifier.width(108.dp)) { onPreset(GroupSelectionPreset.ACTIVE) } }',
        1,
    )
    text = text.replace(
        "engine.selectedWhatsAppPackage != null && groups.any { it.selected },\n                onStart,",
        "engine.selectedWhatsAppPackage != null && hasExtractionTargets,\n                onStart,",
        1,
    )
    p.write_text(text, encoding="utf-8")
    print("PATCH Workspace extraction controls")


def patch_extraction_controller():
    p = ROOT / "app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt"
    text = p.read_text(encoding="utf-8")
    marker = "private suspend fun extractionTargets(targetPackage: String): List<TargetGroup>"
    if "ExtractionRunPolicy.shouldProcess(" in text[text.find(marker):text.find(marker)+2500]:
        print("SKIP ExtractionController policy: already applied")
        return
    start = text.find("    private suspend fun extractionTargets(targetPackage: String): List<TargetGroup> {")
    if start < 0:
        die("ExtractionController extractionTargets function not found")
    end = text.find("\n    private suspend fun runExtraction", start)
    if end < 0:
        die("ExtractionController runExtraction boundary not found")
    new = '''    private suspend fun extractionTargets(targetPackage: String): List<TargetGroup> {\n        val all = repository.groups().filter { group ->\n            !group.stale &&\n                group.active &&\n                group.status != GroupStatus.SKIPPED_NOT_GROUP &&\n                (group.whatsappPackage.isBlank() || group.whatsappPackage == targetPackage)\n        }\n        val explicitlySelected = all.filter { it.selected }\n        val base = if (explicitlySelected.isNotEmpty()) explicitlySelected else all.filter { it.discovered }\n        val mode = settingsStore.get().mode\n        return buildList {\n            for (group in base) {\n                val checkpoint = repository.checkpoint(group.name)\n                val syncedAt = group.lastSyncedAt ?: 0L\n                val checkpointGeneration = when {\n                    checkpoint == null -> -1L\n                    checkpoint.updatedAt >= syncedAt -> group.syncGeneration\n                    else -> group.syncGeneration - 1L\n                }\n                val process = ExtractionRunPolicy.shouldProcess(\n                    mode = mode,\n                    group = ExtractionRunGroup(\n                        selected = true,\n                        unreadCount = group.unreadCount,\n                        status = group.status,\n                        stale = group.stale,\n                        active = group.active,\n                        syncGeneration = group.syncGeneration,\n                        checkpointGeneration = checkpointGeneration\n                    ),\n                    manualRecheck = false\n                )\n                if (process) add(group)\n            }\n        }\n    }\n'''
    p.write_text(text[:start] + new + text[end:], encoding="utf-8")
    print("PATCH ExtractionController checkpoint/new-content policy")


def main():
    if not (ROOT / "app/build.gradle.kts").exists():
        die(f"not a BOBO repository root: {ROOT}")
    copy_payload()
    patch_main_activity()
    patch_workspace()
    patch_extraction_controller()
    print("AL-thmany 3.5 overlay installation complete")

if __name__ == "__main__":
    main()
