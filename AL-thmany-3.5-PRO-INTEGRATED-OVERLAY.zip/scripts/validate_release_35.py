from pathlib import Path
import re,sys
root=Path(__file__).resolve().parents[1]
g=(root/'app/build.gradle.kts').read_text()
checks={
 'versionName 3.5': 'versionName = "3.5"' in g,
 'versionCode 500+': bool(re.search(r'versionCode\s*=\s*([5-9]\d\d|\d{4,})',g)),
 'no debug app id suffix': 'applicationIdSuffix' not in g,
 'no debug version suffix': 'versionNameSuffix' not in g,
 'no hardcoded UI 3.4.1': 'Al-othmany Sender 3.4.1' not in (root/'app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt').read_text(),
 'diagnostics not 3.4.1': 'AL-thmany 3.4.1 Runtime Diagnostic' not in (root/'app/src/main/java/com/althmany/extractor/ui/V341DiagnosticsScreen.kt').read_text(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'),k)
sys.exit(0 if all(checks.values()) else 1)
