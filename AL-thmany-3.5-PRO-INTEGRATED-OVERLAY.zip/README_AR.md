# AL-thmany 3.5 — Professional Integrated Overlay

هذه الحزمة موجهة حصراً إلى فرع `phase13-build-test` من مستودع `othma433-ai/BOBO`.

## ما تنفذه الحزمة

- إصدار التطبيق الظاهر: `3.5` مع `versionCode = 500`.
- إزالة `applicationIdSuffix = ".debug"` و`versionNameSuffix = "-debug"` حتى تستخدم نسخة الاختبار هوية التطبيق الأساسية بدلاً من تثبيت نسخة منفصلة.
- إزالة العرض الثابت `3.4.1` من واجهة Compose والتشخيص؛ العرض يأخذ `BuildConfig.VERSION_NAME`.
- توحيد سياسة Runtime لـ `AUTO / Accessibility only / Shizuku only` مع فصل requested/effective backend.
- إضافة requested/effective backend بوضوح في بطاقة Runtime.
- إعدادات Scan: نطاق `الجديد فقط / غير المؤكد / إعادة فحص الكل` + سرعة `فائق / ذكي / دقيق` مع بقاء Scan read-only.
- سياسة Group Registry: أول مزامنة إلزامية، وبعدها Skip Sync تلقائي فقط إذا كان السجل حديثاً وكاملاً ومتوافقاً مع نسخة واتساب.
- إضافة فلتر `المقروءة` إلى اختيار القروبات.
- تحسين Extraction: عدم إعادة القروبات المكتملة دون دليل على محتوى جديد؛ New Only يعالج unread/new checkpoint evidence؛ Deep/Smart يحترمان checkpoint.
- إبقاء نقاط الاستكمال ومنع إعادة العمل بعد التوقف.

## التثبيت في Codespace

افتح Codespace على الفرع `phase13-build-test`، فك الحزمة داخل مجلد مؤقت ثم نفذ:

```bash
python3 <PATH_TO_EXTRACTED_BUNDLE>/scripts/install_althmany35_overlay.py /workspaces/BOBO
cd /workspaces/BOBO
./gradlew testDebugUnitTest --console=plain
./gradlew assembleDebug --console=plain
```

إذا نجح الاختبار والبناء، سيكون APK في:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## بوابة القبول على الجهاز

لا تعتبر النسخة نهائية لمجرد نجاح Gradle. يجب التحقق من:

1. يظهر الإصدار `3.5`.
2. Accessibility متصل أو Shizuku Ready، وRequested/Effective backend صحيحان.
3. Scan يفتح الروابط ويصنفها بدون الضغط على Join أو Request to Join.
4. Scan scopes وسرعاته تعمل.
5. أول تشغيل Extraction يفرض مزامنة القروبات.
6. التشغيل التالي يتخطى المزامنة فقط إذا كان السجل Fresh/Complete.
7. Deep وNew Only يحفظان checkpoint ويستكملان دون إعادة العمل المكتمل بلا سبب.
8. فلتر المقروءة/غير المقروءة/الكل/يدوي يعمل.
9. التصدير يعمل كما في النسخة الحالية.

## ملاحظة مهمة

الحزمة Overlay وليست استبدالاً كاملاً للمشروع، عمداً. Phase13 FullSource القديم يحتوي ملفات UI أقدم من الفرع الحالي، واستبدال `app/` كاملاً سبق أن سبب regressions. المثبت ينسخ فقط الملفات المتوافقة ويطبق تعديلات جراحية على الملفات التي اختلفت في الفرع الحالي.
