# AL-thmany 3.5 — Integrated Runtime, Scan, and Extraction Design

## Scope
This release unifies application settings, runtime selection, Scan, and Extraction into one coherent 3.5 architecture. Join and Publish remain separate modules but consume the same runtime layer.

## Version and identity
- Product display version: `3.5`.
- UI reads version from `BuildConfig.VERSION_NAME`; no hard-coded `3.4.1`.
- User-facing 3.5 candidate preserves the intended primary application identity for upgrade/install behavior.

## Unified Runtime
`UnifiedRuntimeRepository -> RuntimeManager -> RuntimeSession -> RuntimeDriver`

Drivers:
- Accessibility
- Shizuku

Modes:
- AUTO
- Accessibility only
- Shizuku only

AUTO is default. UI shows requested and effective backend. Runtime owns target/profile/backend/readiness/launch/root wait/recovery/fallback/operation ownership/diagnostics.

## Application settings
Sections:
- Runtime settings
- Scan settings
- Extraction settings

Runtime settings expose target WhatsApp/profile, requested/effective backend, connection readiness, Refresh/Repair Runtime, and diagnostics.

## Scan
Input:
- large paste box
- mixed-text URL extraction
- TXT/CSV/JSON/XLS/XLSX
- Add / Replace
- counters: detected/unique/duplicate/invalid/ready

Queue:
- persistent
- one pass/item in normal mode
- checkpoint per item
- interrupted SCANNING -> PENDING
- completed terminal results not automatically rescanned

Scopes:
- New only
- Uncertain only
- Recheck all

Execution:
- permanently read-only
- never clicks Join or Request to Join
- opens each invite in selected WhatsApp
- freshness guard against stale screen
- max two snapshots in fast policy
- same-item runtime recovery
- direct next-link navigation while WhatsApp stays foregrounded

Classification:
DIRECT, APPROVAL, REQUEST_PENDING, ALREADY_MEMBER, EXPIRED, INVALID, FULL, REMOVED, ACCOUNT_LIMIT, NETWORK_ERROR, UNKNOWN.
InviteKind: GROUP / COMMUNITY / UNKNOWN.

Metadata:
group name, explicit member count, numeric count, separate +NN visible indicator, confidence, signal code, duration, target package/profile, scanned time.

Export:
XLSX / CSV / TXT / JSON with all audit fields and status-specific sheets.

## Extraction
Canonical flow:
`Select WhatsApp -> Sync groups -> Group Registry -> Filter -> Extraction`

### Synchronization policy
Selected option 2:
- Full sync mandatory first run.
- Later runs may show `Skip synchronization` only when registry is recent, complete, valid.
- Force sync if stale/incomplete, target/profile changed, or integrity fails.

### Group Registry
Stable local identity:
- local ID
- display/normalized name
- target package/profile
- signature where available
- read/unread snapshot
- extraction checkpoint
- completion state
- last-seen/new-content indicators

Name alone is never the only identity key.

### Filters
All / Unread only / Read only / Manual / Deselect all.

### Deep Extraction
- open group
- capture on entry
- capture during every movement
- adaptive traversal to checkpoint/oldest target range
- extract historical range
- verify end
- persist checkpoint/completion

### New Only
- process groups with new/unread content or content beyond checkpoint
- seek oldest unread/checkpoint boundary
- capture during movement
- extract forward through new content
- persist checkpoint

### Extraction intelligence
- capture before/during/after scrolling
- adaptive scrolling
- deduplicate message/group/run/global
- completed groups not fully reprocessed unless new content or manual recheck
- intelligent next-group transition
- search/registry fallback
- stale-tree handling
- checkpoint/resume
- Pause / Resume / Stop / Retry failed
- same semantics on Accessibility/Shizuku
- single-operation ownership

## UI
Arabic-first RTL. Scan and Extraction settings separated. Runtime state must be real, not decorative. Buttons enabled only when prerequisites are actually satisfied.

## Persistence
Additive migrations only. Preserve scan results, queues, extraction registry/checkpoints/history across process death/device restart.

## Verification gates
1. Unit tests
2. Android compile
3. assembleDebug
4. runtime requested/effective backend correct
5. backend READY on-device
6. scan smoke test without membership clicks
7. scan resume/recovery
8. exports
9. first-run full group sync
10. skip-sync validity/staleness
11. Deep Extraction smoke test
12. New Only smoke test
13. extraction checkpoint/resume
14. duplicate prevention
15. on-device APK verification before main merge

## Release policy
Keep work on test branch until all gates pass. No merge to `main` before device verification. Release candidate displays version `3.5`.
