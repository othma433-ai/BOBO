# AL-thmany 3.5 Master Implementation Plan

This master plan implements `AL-thmany-3.5-integrated-design.md` in four independently testable sub-projects:

1. `AL-thmany-3.5-plan-01-runtime-settings.md`
2. `AL-thmany-3.5-plan-02-scan.md`
3. `AL-thmany-3.5-plan-03-extraction.md`
4. `AL-thmany-3.5-plan-04-integration-release.md`

Execution order is mandatory: Runtime/Settings → Scan → Extraction → Integration/Release.

Each subsystem follows Red/Green/Refactor and must be independently green before integration. No subsystem may bypass RuntimeManager, no database change may be destructive, and no merge to main occurs before the device acceptance gates in plan 04 pass.
