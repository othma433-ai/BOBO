package com.althmany.extractor.engine

import com.althmany.extractor.data.ExtractionMode
import com.althmany.extractor.data.GroupStatus

data class ExtractionRunGroup(
    val selected: Boolean,
    val unreadCount: Int,
    val status: GroupStatus,
    val stale: Boolean,
    val active: Boolean,
    val syncGeneration: Long,
    val checkpointGeneration: Long
)

/** Prevents needless reprocessing while still allowing genuinely new group content. */
object ExtractionRunPolicy {
    fun shouldProcess(mode: ExtractionMode, group: ExtractionRunGroup, manualRecheck: Boolean): Boolean {
        if (!group.selected || group.stale || !group.active) return false
        if (manualRecheck) return true

        val newGeneration = group.syncGeneration > group.checkpointGeneration
        return when (mode) {
            ExtractionMode.NEW_ONLY -> group.unreadCount > 0 || newGeneration || group.status != GroupStatus.COMPLETED
            else -> group.status != GroupStatus.COMPLETED || newGeneration
        }
    }
}
