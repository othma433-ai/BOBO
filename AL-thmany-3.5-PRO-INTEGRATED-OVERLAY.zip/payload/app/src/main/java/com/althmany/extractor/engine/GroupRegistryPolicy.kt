package com.althmany.extractor.engine

enum class GroupRegistryFreshness { MISSING, FRESH, STALE, INCOMPLETE, TARGET_MISMATCH }

data class GroupRegistryRow(
    val name: String,
    val whatsappPackage: String,
    val lastSyncedAt: Long?,
    val syncGeneration: Long,
    val stale: Boolean,
    val discovered: Boolean
)

data class GroupRegistryAssessment(
    val freshness: GroupRegistryFreshness,
    val canSkipSync: Boolean,
    val activeGroupCount: Int,
    val newestSyncAt: Long?,
    val syncGeneration: Long?,
    val detailAr: String
)

/**
 * Decides whether the synchronized group registry is safe to reuse.
 * A complete registry has one positive sync generation for the selected package and no stale rows.
 */
object GroupRegistryPolicy {
    const val FRESH_WINDOW_MS: Long = 6L * 60L * 60L * 1000L

    fun assess(rows: List<GroupRegistryRow>, targetPackage: String?, nowMs: Long): GroupRegistryAssessment {
        val target = targetPackage?.trim().orEmpty()
        if (target.isBlank()) return GroupRegistryAssessment(
            GroupRegistryFreshness.TARGET_MISMATCH, false, 0, null, null,
            "اختر نسخة واتساب قبل استخدام سجل المزامنة"
        )

        val discovered = rows.filter { it.discovered }
        if (discovered.isEmpty()) return GroupRegistryAssessment(
            GroupRegistryFreshness.MISSING, false, 0, null, null,
            "لا توجد مزامنة مكتملة بعد — المزامنة الأولى إلزامية"
        )

        val matching = discovered.filter { it.whatsappPackage == target || it.whatsappPackage.isBlank() }
        if (matching.isEmpty()) return GroupRegistryAssessment(
            GroupRegistryFreshness.TARGET_MISMATCH, false, 0, null, null,
            "سجل القروبات يخص نسخة واتساب مختلفة"
        )

        if (matching.any { it.stale }) return GroupRegistryAssessment(
            GroupRegistryFreshness.INCOMPLETE, false, matching.count { !it.stale },
            matching.mapNotNull { it.lastSyncedAt }.maxOrNull(), null,
            "سجل القروبات غير مكتمل ويحتاج إعادة مزامنة"
        )

        val generations = matching.map { it.syncGeneration }.filter { it > 0L }.distinct()
        if (generations.size != 1 || matching.any { it.syncGeneration <= 0L }) return GroupRegistryAssessment(
            GroupRegistryFreshness.INCOMPLETE, false, matching.size,
            matching.mapNotNull { it.lastSyncedAt }.maxOrNull(), generations.singleOrNull(),
            "هناك أكثر من جيل مزامنة أو مزامنة غير مكتملة"
        )

        val newest = matching.mapNotNull { it.lastSyncedAt }.maxOrNull()
        if (newest == null || nowMs - newest !in 0..FRESH_WINDOW_MS) return GroupRegistryAssessment(
            GroupRegistryFreshness.STALE, false, matching.size, newest, generations.single(),
            "المزامنة قديمة ويجب تحديث القروبات"
        )

        return GroupRegistryAssessment(
            GroupRegistryFreshness.FRESH, true, matching.size, newest, generations.single(),
            "سجل القروبات حديث ومكتمل — يمكن تخطي المزامنة"
        )
    }
}
