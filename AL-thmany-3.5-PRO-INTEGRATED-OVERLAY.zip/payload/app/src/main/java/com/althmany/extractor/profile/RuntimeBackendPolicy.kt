package com.althmany.extractor.profile

/** Pure backend-selection policy shared by Runtime UI and engines. */
object RuntimeBackendPolicy {
    fun resolve(
        preference: RuntimeBackendPreference,
        remoteTarget: Boolean,
        accessibilityReady: Boolean,
        shizukuReady: Boolean
    ): RuntimeBackendKind {
        if (remoteTarget) {
            return if (preference != RuntimeBackendPreference.ACCESSIBILITY && shizukuReady) {
                RuntimeBackendKind.SHIZUKU
            } else RuntimeBackendKind.NONE
        }
        return when (preference) {
            RuntimeBackendPreference.ACCESSIBILITY ->
                if (accessibilityReady) RuntimeBackendKind.ACCESSIBILITY else RuntimeBackendKind.NONE
            RuntimeBackendPreference.SHIZUKU ->
                if (shizukuReady) RuntimeBackendKind.SHIZUKU else RuntimeBackendKind.NONE
            RuntimeBackendPreference.AUTO -> when {
                accessibilityReady -> RuntimeBackendKind.ACCESSIBILITY
                shizukuReady -> RuntimeBackendKind.SHIZUKU
                else -> RuntimeBackendKind.NONE
            }
        }
    }
}
