package com.althmany.extractor.profile

enum class RuntimeBackendPreference(val labelAr: String) {
    AUTO("تلقائي — Accessibility ثم Shizuku"),
    ACCESSIBILITY("Accessibility فقط"),
    SHIZUKU("Shizuku فقط")
}

enum class RuntimeBackendKind { ACCESSIBILITY, SHIZUKU, NONE }
