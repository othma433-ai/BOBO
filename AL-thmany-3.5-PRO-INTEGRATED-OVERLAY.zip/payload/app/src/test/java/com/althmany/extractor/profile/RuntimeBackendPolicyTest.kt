package com.althmany.extractor.profile

import org.junit.Assert.assertEquals
import org.junit.Test

class RuntimeBackendPolicyTest {
    @Test fun autoLocalPrefersAccessibilityThenShizuku() {
        assertEquals(RuntimeBackendKind.ACCESSIBILITY, RuntimeBackendPolicy.resolve(RuntimeBackendPreference.AUTO, false, true, true))
        assertEquals(RuntimeBackendKind.SHIZUKU, RuntimeBackendPolicy.resolve(RuntimeBackendPreference.AUTO, false, false, true))
        assertEquals(RuntimeBackendKind.NONE, RuntimeBackendPolicy.resolve(RuntimeBackendPreference.AUTO, false, false, false))
    }

    @Test fun remoteTargetRequiresShizuku() {
        assertEquals(RuntimeBackendKind.SHIZUKU, RuntimeBackendPolicy.resolve(RuntimeBackendPreference.AUTO, true, true, true))
        assertEquals(RuntimeBackendKind.NONE, RuntimeBackendPolicy.resolve(RuntimeBackendPreference.ACCESSIBILITY, true, true, true))
        assertEquals(RuntimeBackendKind.NONE, RuntimeBackendPolicy.resolve(RuntimeBackendPreference.SHIZUKU, true, true, false))
    }

    @Test fun manualModeNeverCrossFallsBack() {
        assertEquals(RuntimeBackendKind.NONE, RuntimeBackendPolicy.resolve(RuntimeBackendPreference.ACCESSIBILITY, false, false, true))
        assertEquals(RuntimeBackendKind.NONE, RuntimeBackendPolicy.resolve(RuntimeBackendPreference.SHIZUKU, false, true, false))
    }
}
