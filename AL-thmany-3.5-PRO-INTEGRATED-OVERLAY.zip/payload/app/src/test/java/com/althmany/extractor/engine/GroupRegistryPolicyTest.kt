package com.althmany.extractor.engine

import org.junit.Assert.*
import org.junit.Test

class GroupRegistryPolicyTest {
    private val now = 1_000_000L

    @Test fun firstRunRequiresSync() {
        val s = GroupRegistryPolicy.assess(emptyList(), "com.whatsapp", now)
        assertFalse(s.canSkipSync)
        assertEquals(GroupRegistryFreshness.MISSING, s.freshness)
    }

    @Test fun freshCompleteMatchingRegistryCanSkip() {
        val rows = listOf(
            GroupRegistryRow("g1", "com.whatsapp", now - 1_000, 10L, false, true),
            GroupRegistryRow("g2", "com.whatsapp", now - 2_000, 10L, false, true)
        )
        val s = GroupRegistryPolicy.assess(rows, "com.whatsapp", now)
        assertTrue(s.canSkipSync)
        assertEquals(2, s.activeGroupCount)
        assertEquals(GroupRegistryFreshness.FRESH, s.freshness)
    }

    @Test fun staleIncompleteOrTargetMismatchForcesSync() {
        val old = now - GroupRegistryPolicy.FRESH_WINDOW_MS - 1
        assertFalse(GroupRegistryPolicy.assess(listOf(GroupRegistryRow("g", "com.whatsapp", old, 1, false, true)), "com.whatsapp", now).canSkipSync)
        assertFalse(GroupRegistryPolicy.assess(listOf(GroupRegistryRow("g", "com.whatsapp", now, 1, true, true)), "com.whatsapp", now).canSkipSync)
        assertFalse(GroupRegistryPolicy.assess(listOf(GroupRegistryRow("g", "com.whatsapp.w4b", now, 1, false, true)), "com.whatsapp", now).canSkipSync)
    }
}
