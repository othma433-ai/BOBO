package com.althmany.extractor.engine

import com.althmany.extractor.data.ExtractionMode
import com.althmany.extractor.data.GroupStatus
import org.junit.Assert.*
import org.junit.Test

class ExtractionRunPolicyTest {
    @Test fun deepDoesNotRedoCompletedWithoutNewEvidence() {
        val row = ExtractionRunGroup(selected=true, unreadCount=0, status=GroupStatus.COMPLETED, stale=false, active=true, syncGeneration=7, checkpointGeneration=7)
        assertFalse(ExtractionRunPolicy.shouldProcess(ExtractionMode.DEEP, row, manualRecheck=false))
        assertTrue(ExtractionRunPolicy.shouldProcess(ExtractionMode.DEEP, row.copy(syncGeneration=8), manualRecheck=false))
        assertTrue(ExtractionRunPolicy.shouldProcess(ExtractionMode.DEEP, row, manualRecheck=true))
    }

    @Test fun newOnlyRequiresNewOrUnreadContent() {
        val base = ExtractionRunGroup(true,0,GroupStatus.COMPLETED,false,true,4,4)
        assertFalse(ExtractionRunPolicy.shouldProcess(ExtractionMode.NEW_ONLY, base, false))
        assertTrue(ExtractionRunPolicy.shouldProcess(ExtractionMode.NEW_ONLY, base.copy(unreadCount=2), false))
        assertTrue(ExtractionRunPolicy.shouldProcess(ExtractionMode.NEW_ONLY, base.copy(syncGeneration=5), false))
    }

    @Test fun neverProcessesUnselectedStaleOrInactive() {
        val good = ExtractionRunGroup(true,1,GroupStatus.PENDING,false,true,1,0)
        assertFalse(ExtractionRunPolicy.shouldProcess(ExtractionMode.DEEP, good.copy(selected=false), false))
        assertFalse(ExtractionRunPolicy.shouldProcess(ExtractionMode.DEEP, good.copy(stale=true), false))
        assertFalse(ExtractionRunPolicy.shouldProcess(ExtractionMode.DEEP, good.copy(active=false), false))
    }
}
