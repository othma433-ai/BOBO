# AL-thmany 4.0 Smart Runtime Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build AL-thmany 4.0 as a profile-aware Smart Auto runtime with bounded recovery, adaptive performance, same-item handover, active-operation floating controls, and a cleaner professional UI without breaking Scan read-only semantics.

**Architecture:** Introduce a runtime core between feature controllers and Accessibility/Shizuku. Feature controllers keep their domain logic, while target/backend choice, runtime health, command routing, pause/resume/stop, target-loss handling, recovery, and performance pacing move into focused runtime components. Overlay and notifications send commands only through a shared command bus; they never execute automation logic.

**Tech Stack:** Android/Kotlin, Coroutines/StateFlow, Compose, Foreground Service, `TYPE_APPLICATION_OVERLAY`, AccessibilityService, Shizuku UserService, Room/SharedPreferences where existing persistence already applies, JUnit 4.

**Spec:** `AL-thmany-4.0-SMART-RUNTIME-DESIGN-SPEC.md`

## Global Constraints

- Target branch: `phase13-build-test`.
- Target release: `versionName = "4.0"`, `versionCode = 600`.
- Smart Auto is the default; manual Accessibility-only and Shizuku-only remain under Advanced Settings.
- Local PERSONAL/OWNER target prefers healthy Accessibility.
- Remote/Work/Secure/Dual target prefers fully-ready Shizuku.
- Requested backend and effective backend remain distinct.
- One operation owner at a time across Join / Scan / Extraction / Publish.
- No blind UI actions; exact target/profile and fresh UI evidence are required.
- Same-item checkpoint must survive pause, target loss, backend handover, and process recreation.
- `uiautomator dump` is bounded compatibility fallback, never the normal hot path.
- Scan remains read-only and must never click Join or Request to Join.
- Floating controls appear only while an operation is active; notification controls remain fallback.
- No merge to `main` until unit tests, Android build, and device smoke gates pass.

---

## File Structure

### New runtime core
- `app/src/main/java/com/althmany/extractor/runtime/SmartRuntimeTypes.kt` — runtime state/health/failure/circuit/performance enums and immutable snapshots.
- `app/src/main/java/com/althmany/extractor/runtime/RuntimeSession.kt` — current session state and checkpoint identity.
- `app/src/main/java/com/althmany/extractor/runtime/SmartBackendPolicy.kt` — pure backend selection logic.
- `app/src/main/java/com/althmany/extractor/runtime/RuntimeHealthMonitor.kt` — health scoring from heartbeat/snapshot/stale/target-loss/failure telemetry.
- `app/src/main/java/com/althmany/extractor/runtime/RuntimeCircuitBreaker.kt` — bounded Shizuku/Accessibility circuit state.
- `app/src/main/java/com/althmany/extractor/runtime/AdaptivePerformanceGovernor.kt` — FAST/BALANCED/SAFE/RECOVERY selection.
- `app/src/main/java/com/althmany/extractor/runtime/RuntimeCommandBus.kt` — idempotent PAUSE/RESUME/STOP/RETURN_TO_TARGET routing.
- `app/src/main/java/com/althmany/extractor/runtime/SmartRuntimeManager.kt` — session lifecycle, backend handover, target-loss policy, runtime snapshots.

### New floating control subsystem
- `app/src/main/java/com/althmany/extractor/overlay/FloatingControlService.kt` — foreground overlay lifecycle only.
- `app/src/main/java/com/althmany/extractor/overlay/FloatingControlView.kt` — compact draggable control surface.
- `app/src/main/java/com/althmany/extractor/overlay/OverlayPermission.kt` — permission checks/open settings.
- `app/src/main/java/com/althmany/extractor/overlay/OverlayController.kt` — show/hide based on runtime active state.

### Existing integration points
- `app/src/main/AndroidManifest.xml` — overlay permission/service declaration and foreground service type as applicable.
- `app/src/main/java/com/althmany/extractor/profile/UnifiedRuntimeTarget.kt` — delegate backend choice to SmartBackendPolicy.
- `app/src/main/java/com/althmany/extractor/engine/RuntimeOperationCoordinator.kt` — publish owner transitions to runtime manager without changing ownership semantics.
- `app/src/main/java/com/althmany/extractor/engine/ScanController.kt` — consume runtime session, same-item recovery, target-loss pause, governor pacing.
- `app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt` — consume runtime session/checkpoint and target-loss pause.
- `app/src/main/java/com/althmany/extractor/engine/PublishController.kt` — consume command bus/pause/stop and target-loss protection.
- `app/src/main/java/com/althmany/extractor/join/OriginalJoinCoordinator.kt` — bridge sender/join state into the runtime session without duplicating automation logic.
- `app/src/main/java/com/althmany/groupmanager/shizuku/ShizukuAutomationService.kt` — bounded command-dump circuit, log throttling, no infinite kill loop.
- `app/src/main/java/com/althmany/extractor/ui/AppViewModel.kt` — Smart Auto default, runtime commands, overlay permission state, professional user-facing status.
- `app/src/main/java/com/althmany/extractor/ui/UnifiedRuntimeCard.kt` — requested/effective backend + health + performance mode.
- `app/src/main/java/com/althmany/extractor/ui/ProfessionalJoinScanScreens.kt` and workspace screens — Advanced Settings separation and overlay permission prompt.
- `app/build.gradle.kts` — 4.0/600 release metadata.

### Tests
- `app/src/test/java/com/althmany/extractor/runtime/SmartBackendPolicyTest.kt`
- `app/src/test/java/com/althmany/extractor/runtime/RuntimeCircuitBreakerTest.kt`
- `app/src/test/java/com/althmany/extractor/runtime/RuntimeHealthMonitorTest.kt`
- `app/src/test/java/com/althmany/extractor/runtime/AdaptivePerformanceGovernorTest.kt`
- `app/src/test/java/com/althmany/extractor/runtime/RuntimeCommandBusTest.kt`
- `app/src/test/java/com/althmany/extractor/runtime/SmartRuntimeManagerTest.kt`
- Extend existing `ScanRuntimeRecoveryPolicyTest` / scan tests.

---

### Task 1: Runtime types and Smart Auto backend policy

**Files:**
- Create: `app/src/main/java/com/althmany/extractor/runtime/SmartRuntimeTypes.kt`
- Create: `app/src/main/java/com/althmany/extractor/runtime/SmartBackendPolicy.kt`
- Test: `app/src/test/java/com/althmany/extractor/runtime/SmartBackendPolicyTest.kt`

**Interfaces:**
- Consumes: `RuntimeBackendPreference`, `RuntimeBackendKind` from existing profile package.
- Produces: `RuntimeTargetHealth`, `RuntimeBackendDecision`, `SmartBackendPolicy.resolve(input): RuntimeBackendDecision`.

- [ ] **Step 1: Write failing tests** for local AUTO Accessibility-first, local fallback to Shizuku, remote Shizuku-first, remote profile-safe Accessibility fallback, and manual modes never crossing backend.
- [ ] **Step 2: Run** `./gradlew testDebugUnitTest --tests '*SmartBackendPolicyTest' --console=plain` and verify failure because production types/policy do not exist.
- [ ] **Step 3: Implement minimal pure policy** with no Android dependencies; decision must include requested backend, effective backend, reason code, and blocked flag.
- [ ] **Step 4: Run the targeted test** and verify all cases pass.
- [ ] **Step 5: Run existing runtime policy tests** to prove no semantic regression.
- [ ] **Step 6: Commit** `feat(runtime): add smart backend selection policy`.

### Task 2: Circuit breaker and health model

**Files:**
- Create: `app/src/main/java/com/althmany/extractor/runtime/RuntimeCircuitBreaker.kt`
- Create: `app/src/main/java/com/althmany/extractor/runtime/RuntimeHealthMonitor.kt`
- Test: corresponding JUnit tests.

**Interfaces:**
- Produces: `CircuitState`, `CircuitDecision`, `RuntimeHealthState`, `RuntimeTelemetry`, `RuntimeHealthSnapshot`.
- `RuntimeCircuitBreaker.recordFailure(kind, nowMs)` opens the command-dump circuit after two `SHIZUKU_DUMP_KILLED` failures in the configured short window and exposes `retryAfterMs`.
- `RuntimeHealthMonitor.evaluate(telemetry)` returns HEALTHY / DEGRADED / RECOVERING / BLOCKED with a reason code.

- [ ] **Step 1:** Write red tests for two-kill circuit open, expiry/half-open behavior, permission loss => BLOCKED, stale bursts => DEGRADED, target loss => RECOVERING.
- [ ] **Step 2:** Run targeted tests and confirm red.
- [ ] **Step 3:** Implement pure state machines with monotonic time supplied by caller; no sleeping inside policy classes.
- [ ] **Step 4:** Run targeted tests and confirm green.
- [ ] **Step 5:** Commit `feat(runtime): add health and circuit breakers`.

### Task 3: Adaptive performance governor

**Files:**
- Create: `app/src/main/java/com/althmany/extractor/runtime/AdaptivePerformanceGovernor.kt`
- Test: `AdaptivePerformanceGovernorTest.kt`

**Interfaces:**
- Produces `RuntimePerformanceMode = FAST | BALANCED | SAFE | RECOVERY` and `RuntimePacing(snapshotPollMs, settleMs, maxSnapshotAttempts, notificationThrottleMs)`.

- [ ] **Step 1:** Write tests proving FAST on healthy low-latency sessions, BALANCED under modest latency, SAFE under stale/error pressure, RECOVERY while recovering.
- [ ] **Step 2:** Confirm red.
- [ ] **Step 3:** Implement hysteresis so one slow frame does not oscillate modes.
- [ ] **Step 4:** Confirm green and run policy test group.
- [ ] **Step 5:** Commit `feat(runtime): add adaptive performance governor`.

### Task 4: Runtime session and command bus

**Files:**
- Create: `RuntimeSession.kt`
- Create: `RuntimeCommandBus.kt`
- Test: `RuntimeCommandBusTest.kt`

**Interfaces:**
- Commands: `PAUSE`, `RESUME`, `STOP`, `RETURN_TO_TARGET`.
- `RuntimeCommandBus.commands: SharedFlow<RuntimeCommand>` and `send(command)` are idempotent for repeated terminal/duplicate commands.
- Session stores operation owner, target identity, requested/effective backend, checkpoint reference, health, performance mode, failure counters, last snapshot signature, last recovery reason.

- [ ] **Step 1:** Write tests for duplicate pause/stop coalescing and owner-scoped command delivery.
- [ ] **Step 2:** Confirm red.
- [ ] **Step 3:** Implement command bus and session model.
- [ ] **Step 4:** Confirm green.
- [ ] **Step 5:** Commit `feat(runtime): add session and command bus`.

### Task 5: SmartRuntimeManager lifecycle and same-item handover

**Files:**
- Create: `SmartRuntimeManager.kt`
- Modify: `RuntimeOperationCoordinator.kt`
- Modify: `UnifiedRuntimeTarget.kt`
- Test: `SmartRuntimeManagerTest.kt`

**Interfaces:**
- `begin(operation, target, preference)` starts/resolves one session.
- `checkpoint(itemId, checkpointRef, signature)` persists current identity before recovery.
- `reportTelemetry(...)` updates health/performance/circuit state.
- `requestHandover(failure)` returns a handover plan; it never advances the queue.
- `markTargetLost()` transitions to `PAUSED_OUTSIDE_TARGET` and stops input authorization.

- [ ] **Step 1:** Write state-machine tests for begin → running, target loss → paused, local Shizuku failure → same-item Accessibility handover, manual mode no crossover, STOP terminal behavior.
- [ ] **Step 2:** Confirm red.
- [ ] **Step 3:** Implement manager around existing owner coordinator; do not replace controller business logic.
- [ ] **Step 4:** Confirm green.
- [ ] **Step 5:** Run all runtime tests.
- [ ] **Step 6:** Commit `feat(runtime): add smart runtime session manager`.

### Task 6: Fix Shizuku kill loop at the source

**Files:**
- Modify: `app/src/main/java/com/althmany/groupmanager/shizuku/ShizukuAutomationService.kt`
- Add/extend pure policy tests where possible.

**Interfaces:**
- Existing persistent snapshot path remains primary.
- Command dump is allowed only when circuit permits.
- Two real `exit=137`/Killed failures open a 12–15s circuit.
- Cooldown log emits once on open and once on close/half-open, not each poll.
- Successful persistent snapshot closes/reset relevant command circuit.

- [ ] **Step 1:** Add regression tests to the extracted circuit policy representing the exact device journal: kill → cooldown → kill → circuit open, no repeated command spawn.
- [ ] **Step 2:** Confirm red against old service integration helper/policy.
- [ ] **Step 3:** Replace service-local one-second suppression loop with RuntimeCircuitBreaker decisions and throttled diagnostics.
- [ ] **Step 4:** Ensure manual Shizuku reports blocked/degraded instead of silently switching backend.
- [ ] **Step 5:** Run unit tests and `./gradlew compileDebugKotlin --console=plain`.
- [ ] **Step 6:** Commit `fix(shizuku): bound killed uiautomator recovery`.

### Task 7: Scan integration with same-item recovery

**Files:**
- Modify: `ScanController.kt`
- Modify/extend: `ScanRuntimeRecoveryPolicy.kt`
- Extend scan tests.

**Interfaces:**
- Scan obtains effective backend from SmartRuntimeManager.
- On target loss it pauses and checkpoints, never clicks elsewhere.
- On AUTO backend hard failure, current `ScanRecord.id` is retained through handover and fresh-screen verification.
- Scan remains `SCAN_ONLY` with request-to-join disabled.

- [ ] **Step 1:** Add regression tests for local AUTO choosing Accessibility when root is healthy, target loss pause, Shizuku kill fallback to Accessibility on same record, and no membership action.
- [ ] **Step 2:** Confirm red.
- [ ] **Step 3:** Integrate manager/command bus/governor while preserving existing classification logic.
- [ ] **Step 4:** Confirm targeted scan tests green.
- [ ] **Step 5:** Commit `feat(scan): use smart runtime and same-item recovery`.

### Task 8: Extraction / Publish / Join runtime integration

**Files:**
- Modify: `ExtractionController.kt`
- Modify: `PublishController.kt`
- Modify: `OriginalJoinCoordinator.kt`
- Extend tests for operation ownership and pause/resume.

**Interfaces:**
- All controllers respond to RuntimeCommandBus through their existing pause/resume/stop mechanisms.
- Target loss causes safe pause and checkpoint.
- No controller independently overrides backend selection while Smart Auto session is active.

- [ ] **Step 1:** Write failing integration-level unit tests using fake runtime state for owner collision, target-loss pause, resume same checkpoint, and terminal stop.
- [ ] **Step 2:** Confirm red.
- [ ] **Step 3:** Add minimal adapters around existing controllers; do not duplicate their extraction/join/publish algorithms.
- [ ] **Step 4:** Confirm tests green.
- [ ] **Step 5:** Commit `feat(runtime): unify feature command handling`.

### Task 9: Floating controls foreground service

**Files:**
- Create: `OverlayPermission.kt`
- Create: `FloatingControlService.kt`
- Create: `FloatingControlView.kt`
- Create: `OverlayController.kt`
- Modify: `AndroidManifest.xml`
- Add service/controller tests where Android-independent state can be extracted.

**Interfaces:**
- Overlay is visible iff operation state is active/nonterminal and overlay permission is granted.
- Buttons send only RuntimeCommandBus commands.
- Bubble supports drag and collapse; expanded surface shows operation, progress, health, Pause/Resume, Stop, Return to WhatsApp.
- Service self-stops on terminal runtime state.

- [ ] **Step 1:** Write pure visibility/action mapping tests.
- [ ] **Step 2:** Confirm red.
- [ ] **Step 3:** Add `android.permission.SYSTEM_ALERT_WINDOW`, foreground service declaration, notification channel, and overlay implementation.
- [ ] **Step 4:** Implement draggable/clamped positioning and compact bubble.
- [ ] **Step 5:** Add notification fallback actions using the same command bus when overlay permission is absent.
- [ ] **Step 6:** Run compile + unit tests.
- [ ] **Step 7:** Commit `feat(overlay): add active-operation floating controls`.

### Task 10: Professional Smart Auto UI and diagnostics

**Files:**
- Modify: `AppViewModel.kt`
- Modify: `UnifiedRuntimeCard.kt`
- Modify workspace/settings screens.
- Modify diagnostics screen to use `BuildConfig.VERSION_NAME` and smart runtime snapshot.

**Interfaces:**
- Default UI shows Smart Auto, selected WhatsApp, effective backend, health, and operation state.
- Advanced Settings contains manual backend override and technical controls.
- Diagnostics exposes requested/effective backend, profile, circuit state, last recovery reason, snapshot latency, stale count, and performance mode.

- [ ] **Step 1:** Add view-model tests for display-model mapping where possible.
- [ ] **Step 2:** Implement Arabic-first RTL cards with concise healthy/degraded/recovering/blocked messages.
- [ ] **Step 3:** Add one-time overlay permission CTA; no repeated prompt once declined.
- [ ] **Step 4:** Remove hard-coded `3.4.1`/`3.5` UI strings and use BuildConfig.
- [ ] **Step 5:** Compile and run unit tests.
- [ ] **Step 6:** Commit `feat(ui): add smart runtime controls and diagnostics`.

### Task 11: Release metadata and static regression gate

**Files:**
- Modify: `app/build.gradle.kts`
- Add/update release validation script.

**Interfaces:**
- `versionCode = 600`
- `versionName = "4.0"`
- Debug package identity must be chosen intentionally and documented before device install; do not accidentally change the package during this task.

- [ ] **Step 1:** Add validation assertions for release version, no hard-coded old version labels, manifest overlay service, scan read-only settings, and Smart Auto default.
- [ ] **Step 2:** Confirm validator fails before metadata update.
- [ ] **Step 3:** Update metadata and UI references.
- [ ] **Step 4:** Run validator and confirm pass.
- [ ] **Step 5:** Commit `chore(release): prepare AL-thmany 4.0 metadata`.

### Task 12: Full verification and device acceptance

**Files:** No new production design; verification only unless a failing gate finds a defect.

- [ ] **Step 1:** Run `git diff --check`.
- [ ] **Step 2:** Run `./gradlew testDebugUnitTest --console=plain` and require 0 failures.
- [ ] **Step 3:** Run `./gradlew clean assembleDebug --console=plain` and require exit 0.
- [ ] **Step 4:** Install on device and verify local PERSONAL/OWNER Smart Auto resolves Accessibility when Accessibility sees the selected WhatsApp.
- [ ] **Step 5:** Verify Shizuku local failure journal no longer repeats `SHIZUKU_COMMAND_DUMP_COOLDOWN` at polling frequency and no repeated killed `uiautomator` spawning after circuit opens.
- [ ] **Step 6:** Start Scan, leave WhatsApp manually, verify immediate safe pause + overlay, no click in other app, then Return/Resume continues same item.
- [ ] **Step 7:** Repeat target-loss flow for Extraction.
- [ ] **Step 8:** Verify floating Pause/Resume/Stop/Return controls and automatic hide on completion/stop.
- [ ] **Step 9:** Revoke overlay permission and verify notification controls remain usable.
- [ ] **Step 10:** Verify Scan is still read-only and never joins/requests membership.
- [ ] **Step 11:** Verify remote profile/Work/Secure path prefers Shizuku and does not use unsafe local Accessibility fallback.
- [ ] **Step 12:** Verify checkpoint/resume, duplicate prevention, exports, and operation-owner collision protection.
- [ ] **Step 13:** Only after all gates pass, produce release candidate APK/artifact and consider merge to `main`.

---

## Self-Review Result

- Spec coverage: runtime selection, health, circuit breaker, performance governor, same-item handover, target-loss pause, overlay, notification fallback, UI, diagnostics, release metadata, and device gates are mapped to explicit tasks.
- No task permits Scan membership actions.
- No task merges to `main` before device acceptance.
- Package identity is intentionally deferred to release verification because changing/removing the debug suffix affects update/install behavior and Accessibility binding.
- The plan avoids rewriting domain algorithms; it adds adapters around existing controllers and centralizes only cross-cutting runtime behavior.
