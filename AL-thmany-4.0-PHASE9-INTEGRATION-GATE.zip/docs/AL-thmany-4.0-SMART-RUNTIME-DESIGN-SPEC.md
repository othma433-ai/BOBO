# AL-thmany 4.0 — Smart Runtime & Resilience Design Specification

**Status:** Design Approved in Chat — Written Spec for Final Review  
**Target branch:** `phase13-build-test`  
**Target release:** `4.0`  
**Scope:** Runtime architecture, adaptive performance, anti-freeze/recovery, floating controls, UI/UX reorganization, observability, and cross-feature orchestration for Scan / Extraction / Join / Publish.

---

## 1. Purpose

AL-thmany 4.0 upgrades the current automation runtime from feature-specific backend selection and recovery into a single smart runtime layer that is backend-aware, profile-aware, failure-aware, and checkpoint-aware.

The release must make the application faster, more stable, easier to control while outside WhatsApp, and safer under transient Android/WhatsApp failures. The runtime must never continue UI interaction blindly when the selected WhatsApp target is no longer verified.

---

## 2. Governing Principles

1. **One runtime owner at a time.** Only one of Join / Scan / Extraction / Publish may own WhatsApp UI automation at once.
2. **Requested backend and effective backend are separate concepts.**
3. **Smart Auto is the default.** Manual backend selection remains available under Advanced Settings.
4. **Local PERSONAL/OWNER profile prefers Accessibility when healthy.**
5. **Remote/secondary/profile-isolated targets prefer Shizuku when healthy.**
6. **No blind actions.** Every action requires target/profile verification and fresh UI evidence.
7. **Checkpoint before recovery.** A current item must survive backend handover, target loss, process recreation, and user pause.
8. **Bounded recovery only.** No infinite retries, no repeated `uiautomator dump` loops, no unbounded relaunch loops.
9. **Performance must be adaptive, not permanently maximal.**
10. **Overlay controls are control-only.** They never implement business logic or UI automation themselves.
11. **Notification controls remain the fallback when overlay permission is unavailable.**
12. **Scan remains read-only.** Scan never clicks Join or Request to Join.

---

## 3. Target Architecture

```text
UI / Settings / Floating Controls
            │
            ▼
      RuntimeCommandBus
            │
            ▼
   SmartRuntimeManager
            │
    ┌───────┴────────┐
    ▼                ▼
RuntimeSession   Health/Telemetry
    │                │
    ├─────────┬──────┘
    ▼         ▼
AccessibilityDriver  ShizukuDriver
    │                 │
    └────────┬────────┘
             ▼
      WhatsApp Target
             │
             ▼
Join / Scan / Extraction / Publish
```

### 3.1 Core components

- `SmartRuntimeManager`
  - Resolves target and profile.
  - Chooses effective backend.
  - Owns backend handover.
  - Enforces one operation owner.
  - Coordinates recovery.

- `RuntimeSession`
  - Immutable identity: operation, target package, target profile.
  - Mutable runtime state: requested backend, effective backend, health, current checkpoint, failure counters, circuit states.

- `RuntimeCommandBus`
  - Accepts `PAUSE`, `RESUME`, `STOP`, `RETURN_TO_TARGET`.
  - Used by main UI, floating overlay, and notification actions.
  - Commands are idempotent and routed to the current operation owner.

- `RuntimeHealthMonitor`
  - Tracks heartbeat, snapshot latency, stale UI, backend failures, target foreground state, network state, and recovery activity.

- `AdaptivePerformanceGovernor`
  - Selects pacing mode based on observed runtime health and latency.

- `FloatingControlService`
  - Foreground service using `TYPE_APPLICATION_OVERLAY`.
  - Visible only while an operation is active.
  - Sends commands through `RuntimeCommandBus`.

---

## 4. Runtime State Model

### 4.1 Operation states

```text
IDLE
RESOLVING_TARGET
CHECKING_BACKEND
OPENING_TARGET
WAITING_FOR_ROOT
READY
RUNNING
PAUSED_BY_USER
PAUSED_OUTSIDE_TARGET
RECOVERING
RECOVERY_REQUIRED
COMPLETED
STOPPED
ERROR
```

### 4.2 Runtime health states

```text
HEALTHY
DEGRADED
RECOVERING
BLOCKED
```

Health is descriptive, not a substitute for operation state.

### 4.3 Session fields

A `RuntimeSession` must include at minimum:

- sessionId
- operationOwner
- targetPackage
- targetAndroidUserId / profile identity
- requestedBackend
- effectiveBackend
- startedAt
- currentItemId
- checkpoint reference
- healthState
- lastSuccessfulSnapshotAt
- lastSnapshotSignature
- accessibilityFailureCount
- shizukuFailureCount
- staleUiCount
- targetLossCount
- backendCircuitState(s)
- currentPerformanceMode
- lastRecoveryReason

---

## 5. Smart Auto Backend Selection

### 5.1 Local PERSONAL / OWNER target

Priority:

```text
Accessibility healthy + sees exact target root
        → ACCESSIBILITY
else Shizuku fully ready + valid target snapshot
        → SHIZUKU
else
        → BLOCKED
```

Accessibility is considered healthy only if:

- service is connected;
- heartbeat is recent;
- the selected WhatsApp package is visible in the current root;
- the profile is compatible with the target.

### 5.2 Remote / Work / Secure / Dual target

Priority:

```text
Shizuku fully ready + target user/profile proven
        → SHIZUKU
else profile-safe Accessibility path proven
        → ACCESSIBILITY
else
        → BLOCKED
```

### 5.3 Manual modes

- Accessibility-only: never silently switches to Shizuku.
- Shizuku-only: never silently switches to Accessibility.
- Errors are explicit and actionable.

---

## 6. Backend Health and Circuit Breakers

### 6.1 Shizuku failure taxonomy

At minimum:

- `SHIZUKU_BINDER_LOST`
- `SHIZUKU_PERMISSION_LOST`
- `SHIZUKU_USERSERVICE_LOST`
- `SHIZUKU_SNAPSHOT_EMPTY`
- `SHIZUKU_DUMP_KILLED`
- `SHIZUKU_TARGET_NOT_FOREGROUND`
- `SHIZUKU_STALE_TREE`
- `SHIZUKU_PERSISTENT_UI_UNAVAILABLE`

### 6.2 Command dump policy

`uiautomator dump` is a bounded compatibility fallback, never the primary hot path.

Rules:

1. Persistent event/snapshot path first.
2. One bounded command fallback when semantically justified.
3. If `exit=137` / `Killed` occurs twice within a short window:
   - open command-dump circuit for 12–15 seconds;
   - stop spawning further dump processes during that interval;
   - emit one `CIRCUIT_OPEN` event, not repeated cooldown logs;
   - in Smart Auto local profile, attempt backend handover to Accessibility.
4. Manual Shizuku mode stays on Shizuku and reports `BLOCKED`/`DEGRADED` without silent backend crossover.

### 6.3 Accessibility recovery

On loss of valid root:

1. wait for one fresh event/snapshot window;
2. retry once;
3. if still invalid and Smart Auto allows it, checkpoint and hand over to Shizuku;
4. otherwise enter `RECOVERY_REQUIRED` or `ERROR` based on failure type.

---

## 7. Same-Item Backend Handover

A backend switch must never silently advance the queue.

Required handover sequence:

```text
Failure detected
→ persist current item checkpoint
→ mark session RECOVERING
→ stop inputs on failed backend
→ activate alternate backend
→ reopen SAME target/item if needed
→ verify exact package/profile
→ verify fresh UI signature
→ resume SAME item
```

No item may be marked successful from backend-switch evidence alone.

---

## 8. Adaptive Performance Governor

### 8.1 Inputs

- snapshot latency
- target open latency
- event-to-root latency
- stale-tree rate
- action verification failures
- backend failure rate
- recovery frequency
- CPU-sensitive loop density (indirectly via loop timing)
- network availability

### 8.2 Modes

```text
FAST
BALANCED
SAFE
RECOVERY
```

### 8.3 Behavior

- `FAST`: short waits, event-driven flow, minimal polling.
- `BALANCED`: default steady-state.
- `SAFE`: longer verification windows when WhatsApp/device is slow.
- `RECOVERY`: suspend normal pacing and prioritize safe state restoration.

The governor may move up or down dynamically. It must not change semantic rules, only pacing/retry windows.

---

## 9. Anti-Freeze / Watchdog

The watchdog distinguishes:

- LOADING
- SLOW_UI
- STALE_UI
- TARGET_LOST
- BACKEND_DEGRADED
- BACKEND_FAILED
- NETWORK_WAIT
- USER_PAUSE

Each condition gets a specific response. A slow screen must not be treated as a dead backend, and a dead backend must not be treated as slow loading.

The watchdog must prevent:

- repeated `uiautomator` spawning;
- repeated app relaunch loops;
- repeated identical log entries at sub-second frequency;
- concurrent backend input paths.

---

## 10. Target Exit Behavior

When the user leaves the selected WhatsApp during an active operation:

```text
Target lost
→ immediately stop all UI actions
→ persist checkpoint
→ state = PAUSED_OUTSIDE_TARGET
→ show floating controls
→ keep operation owner reserved
```

No taps, swipes, or key events may be sent while the selected target is not reverified.

### Resume flow

```text
Resume / Return to WhatsApp
→ open selected WhatsApp
→ verify package + profile
→ verify fresh root/snapshot
→ state = RUNNING
→ resume same checkpoint/item
```

---

## 11. Floating Control Service

### 11.1 Visibility

Show only when an operation owner exists and the operation is active or paused.

Hide when:

- COMPLETED
- STOPPED
- terminal ERROR
- no owner

### 11.2 Controls

Initial expanded controls:

- Pause
- Resume
- Stop
- Return to WhatsApp
- Collapse to bubble

### 11.3 Bubble behavior

- draggable
- snaps to nearest side
- compact status indicator
- tap expands
- does not obscure key WhatsApp controls by default

### 11.4 Security/robustness

- Overlay requires `SYSTEM_ALERT_WINDOW` permission.
- If permission missing, app continues normally.
- Notification controls remain available as fallback.
- Overlay does not own or execute automation logic.

---

## 12. Notification Controls

Foreground notification remains active for long-running operations and includes:

- Pause / Resume
- Stop
- Return to target

Notification actions route through `RuntimeCommandBus`, same as overlay.

---

## 13. Process Recreation and Durable Recovery

Durable state must persist enough information to recover safely after activity recreation or process death:

- active operation type
- target package/profile
- current item ID
- checkpoint
- requested backend
- last effective backend
- paused/running intent

If the process is fully restarted, automation must not immediately continue input. It enters:

```text
RECOVERY_REQUIRED
```

Then revalidates target/backend before user or safe policy resumes execution.

---

## 14. Cross-Feature Rules

### Scan

- Read-only permanently.
- No Join / Request actions.
- Uses smart runtime and performance governor.
- Same-item recovery required.

### Extraction

- First full group sync remains mandatory.
- Skip-sync only if registry is fresh/complete/valid for same target/profile.
- Deep and New Only use checkpoints.
- No reprocessing completed groups without new-content evidence or explicit user request.

### Join

- May perform membership actions.
- Uses same runtime session and recovery semantics.

### Publish

- Same owner/runtime controls.
- Must pause if target lost.

---

## 15. UI / UX 4.0

Primary navigation:

```text
Home
Runtime
Scan
Extraction
Join
Publish
Results
Advanced Settings
Diagnostics
```

### 15.1 Home

Show only operationally useful information:

- Smart Auto status
- selected WhatsApp
- current operation
- runtime health
- effective backend
- primary action

### 15.2 Advanced Settings

Contains manual controls:

- backend preference
- performance mode override
- overlay enable/disable
- developer diagnostics
- safe timeout overrides (bounded)

### 15.3 Diagnostics

Use `BuildConfig.VERSION_NAME`.

Show:

- requested backend
- effective backend
- operation owner
- profile identity
- heartbeat
- Shizuku readiness
- circuit states
- performance mode
- health state
- recovery reason

Avoid log spam. Repeated events must be coalesced.

---

## 16. Versioning

Release target:

```text
versionName = "4.0"
versionCode = 600
```

UI version text must always come from `BuildConfig.VERSION_NAME`.

Debug package identity must be chosen deliberately based on installation/upgrade strategy; it must not be changed casually during implementation.

---

## 17. Observability and Logging

Logging policy:

- state transitions: always
- circuit open/close: once per transition
- backend handover: always
- target loss/return: always
- repeated cooldown polling: not logged each iteration
- repeated identical errors: coalesced with count + elapsed time

Suggested event families:

```text
RUNTIME_SESSION_START
RUNTIME_BACKEND_SELECTED
RUNTIME_BACKEND_HANDOVER
RUNTIME_HEALTH_CHANGED
RUNTIME_TARGET_LOST
RUNTIME_TARGET_RESTORED
RUNTIME_CHECKPOINT_SAVED
RUNTIME_RECOVERY_START
RUNTIME_RECOVERY_END
SHIZUKU_CIRCUIT_OPEN
SHIZUKU_CIRCUIT_CLOSED
OVERLAY_SHOWN
OVERLAY_HIDDEN
OVERLAY_COMMAND
```

---

## 18. Testing Strategy

### 18.1 Unit tests

- Smart Auto local backend selection
- Smart Auto remote backend selection
- manual backend no-cross-fallback rules
- circuit breaker open/close behavior
- same-item recovery plan
- target-loss pause policy
- performance mode transitions
- command bus idempotency
- overlay visibility state policy

### 18.2 Integration tests

- Scan local Accessibility
- Scan Shizuku profile
- exit WhatsApp during Scan → pause → resume same item
- exit WhatsApp during Extraction → pause → resume same checkpoint
- Shizuku `exit=137` simulation → circuit open → local fallback
- notification command routing
- overlay command routing
- process recreation → RECOVERY_REQUIRED

### 18.3 Device smoke tests

Must pass before release:

1. Install/upgrade path verified.
2. Smart Auto selects Accessibility on PERSONAL:0 when healthy.
3. Smart Auto selects Shizuku for supported remote profile.
4. Scan remains read-only.
5. Floating controls appear only during active operation.
6. Leaving WhatsApp stops UI actions immediately.
7. Resume returns to same item/checkpoint.
8. Stop terminates operation and hides overlay.
9. `exit=137` does not create a repeating dump loop.
10. Deep Extraction works.
11. New Only works.
12. Group registry skip-sync rules work.
13. Duplicate prevention verified.
14. Logs remain bounded and readable.
15. No concurrent automation owners.

---

## 19. Non-Goals for 4.0

- No machine-learning model is required for runtime decisions.
- No cloud AI dependency.
- No bypass of Android, Knox, Work Profile, or WhatsApp security boundaries.
- No hidden automation while target identity cannot be verified.
- No unlimited retries.

The “smart” behavior is deterministic, observable, telemetry-driven adaptive control.

---

## 20. Release Gate

AL-thmany 4.0 is not considered complete merely because it compiles.

Release requires:

- unit tests pass;
- Android compile passes;
- APK build passes;
- runtime policy tests pass;
- overlay tests pass;
- device smoke tests pass;
- Scan read-only verified;
- target-loss safety verified;
- Shizuku dump-loop regression verified;
- Extraction checkpoint/resume verified;
- final diagnostics report reviewed.

Only after these gates should merge to `main` be considered.

---

## 21. Implementation Boundaries

Implementation should avoid a wholesale replacement of the current `app/` tree. Changes should be incremental and source-aware, preserving working code and existing tests while introducing the new runtime layer behind stable interfaces.

Likely implementation areas include:

- runtime/profile package
- operation coordinator
- ScanController
- ExtractionController
- Join coordinator/runtime bridge
- PublishController
- Shizuku automation runtime
- Accessibility runtime bridge
- app preferences / durable runtime state
- AndroidManifest overlay permission/service
- new FloatingControlService
- notifications/actions
- Compose Runtime/Home/Advanced/Diagnostics screens
- unit/integration tests

