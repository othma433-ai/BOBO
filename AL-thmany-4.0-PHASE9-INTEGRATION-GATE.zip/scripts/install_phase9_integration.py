#!/usr/bin/env python3
from pathlib import Path
import shutil, sys, re

if len(sys.argv) != 2:
    print('usage: install_phase9_integration.py <repo-root>')
    raise SystemExit(2)

bundle = Path(__file__).resolve().parents[1]
repo = Path(sys.argv[1]).resolve()

# 1) Copy canonical v4 sources/tests. Phase 2 supersedes Phase 1 duplicate runtime classes;
# Phase 4 supersedes the Phase 3 RuntimeControlRouter.
for base in [
    'app/src/main/java/com/althmany/extractor/runtime',
    'app/src/main/java/com/althmany/extractor/engine/performance',
    'app/src/main/java/com/althmany/extractor/engine/health',
    'app/src/main/java/com/althmany/extractor/ui/SmartRuntimeHealthPanel.kt',
    'app/src/test/java/com/althmany/extractor/runtime',
    'app/src/test/java/com/althmany/extractor/engine/performance',
    'app/src/test/java/com/althmany/extractor/engine/health',
]:
    src = bundle / base
    if src.is_file():
        dst = repo / base
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        print('COPY', base)
    elif src.is_dir():
        for f in src.rglob('*'):
            if not f.is_file():
                continue
            rel = f.relative_to(bundle)
            dst = repo / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dst)
            print('COPY', rel)


def require(path: str) -> Path:
    p = repo / path
    if not p.exists():
        raise SystemExit(f'Missing required baseline file: {path}')
    return p

# 2) AndroidManifest: overlay permission + active runtime foreground service.
manifest = require('app/src/main/AndroidManifest.xml')
s = manifest.read_text(encoding='utf-8')
if 'android.permission.SYSTEM_ALERT_WINDOW' not in s:
    anchor = '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />'
    if anchor not in s:
        raise SystemExit('Manifest POST_NOTIFICATIONS anchor missing')
    s = s.replace(anchor, anchor + '\n    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />')
if 'com.althmany.extractor.runtime.overlay.FloatingControlService' not in s:
    marker = '        <service\n            android:name=".shizuku.ShizukuAutomationService"'
    block = '''        <service
            android:name="com.althmany.extractor.runtime.overlay.FloatingControlService"
            android:exported="false"
            android:foregroundServiceType="specialUse">
            <property
                android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="User-initiated floating and notification runtime controls while an AL-thmany operation is active" />
        </service>

'''
    if marker not in s:
        raise SystemExit('Manifest Shizuku service anchor missing')
    s = s.replace(marker, block + marker)
manifest.write_text(s, encoding='utf-8')
print('PATCH manifest')

# 3) Application init: initialize lifecycle before restoring any pending recovery state.
app = require('app/src/main/java/com/althmany/groupmanager/GroupManagerApp.kt')
a = app.read_text(encoding='utf-8')
anchor = 'import com.althmany.extractor.ExtractorFeatureRuntime\n'
for imp in [
    'import com.althmany.extractor.runtime.SmartRuntimeLifecycle\n',
    'import com.althmany.extractor.runtime.recovery.TargetRecoveryCoordinator\n',
]:
    if imp not in a:
        if anchor not in a:
            raise SystemExit('GroupManagerApp import anchor missing')
        a = a.replace(anchor, anchor + imp)
init_anchor = '        ExtractorFeatureRuntime.initialize(this)\n'
if 'SmartRuntimeLifecycle.initialize(this)' not in a:
    if init_anchor not in a:
        raise SystemExit('GroupManagerApp init anchor missing')
    a = a.replace(
        init_anchor,
        init_anchor + '        SmartRuntimeLifecycle.initialize(this)\n        TargetRecoveryCoordinator.restorePendingState(this)\n'
    )
elif 'TargetRecoveryCoordinator.restorePendingState(this)' not in a:
    a = a.replace('        SmartRuntimeLifecycle.initialize(this)\n',
                  '        SmartRuntimeLifecycle.initialize(this)\n        TargetRecoveryCoordinator.restorePendingState(this)\n')
app.write_text(a, encoding='utf-8')
print('PATCH GroupManagerApp')

# 4) Single ownership point starts/stops controls and recovery state for every operation.
coord = require('app/src/main/java/com/althmany/extractor/engine/RuntimeOperationCoordinator.kt')
c = coord.read_text(encoding='utf-8')
imp = 'import com.althmany.extractor.runtime.SmartRuntimeLifecycle\n'
if imp not in c:
    pkg = 'package com.althmany.extractor.engine\n'
    if pkg not in c:
        raise SystemExit('RuntimeOperationCoordinator package anchor missing')
    c = c.replace(pkg, pkg + '\n' + imp)
old_try = '''    fun tryAcquire(operation: RuntimeOperation): Boolean {
        // Strict single-owner gate. Sync and Extraction both use EXTRACTION,
        // so the same enum may not re-enter while it already owns WhatsApp UI.
        return owner.compareAndSet(null, operation)
    }
'''
new_try = '''    fun tryAcquire(operation: RuntimeOperation): Boolean {
        // Strict single-owner gate. Sync and Extraction both use EXTRACTION,
        // so the same enum may not re-enter while it already owns WhatsApp UI.
        val acquired = owner.compareAndSet(null, operation)
        if (acquired) SmartRuntimeLifecycle.onAcquired(operation)
        return acquired
    }
'''
if 'SmartRuntimeLifecycle.onAcquired(operation)' not in c:
    if old_try not in c:
        raise SystemExit('RuntimeOperationCoordinator tryAcquire anchor missing')
    c = c.replace(old_try, new_try)
old_ensure = '''    fun ensureOwned(operation: RuntimeOperation): Boolean {
        val current = owner.get()
        if (current == operation) return true
        return owner.compareAndSet(null, operation)
    }
'''
new_ensure = '''    fun ensureOwned(operation: RuntimeOperation): Boolean {
        val current = owner.get()
        if (current == operation) {
            SmartRuntimeLifecycle.onAcquired(operation)
            return true
        }
        val acquired = owner.compareAndSet(null, operation)
        if (acquired) SmartRuntimeLifecycle.onAcquired(operation)
        return acquired
    }
'''
if old_ensure in c:
    c = c.replace(old_ensure, new_ensure)
old_release = '''    fun release(operation: RuntimeOperation) {
        owner.compareAndSet(operation, null)
    }
'''
new_release = '''    fun release(operation: RuntimeOperation) {
        if (owner.compareAndSet(operation, null)) {
            SmartRuntimeLifecycle.onReleased(operation)
        }
    }
'''
if 'SmartRuntimeLifecycle.onReleased(operation)' not in c:
    if old_release not in c:
        raise SystemExit('RuntimeOperationCoordinator release anchor missing')
    c = c.replace(old_release, new_release)

restore_method = '''    /** Restores ownership metadata after process recreation without starting automation. */
    fun restoreForRecovery(operation: RuntimeOperation): Boolean {
        val current = owner.get()
        if (current == operation) return true
        return owner.compareAndSet(null, operation)
    }

'''
if 'fun restoreForRecovery(operation: RuntimeOperation)' not in c:
    anchor_restore = '    fun current(): RuntimeOperation? = owner.get()\n'
    if anchor_restore not in c:
        raise SystemExit('RuntimeOperationCoordinator current() anchor missing')
    c = c.replace(anchor_restore, restore_method + anchor_restore)

coord.write_text(c, encoding='utf-8')
print('PATCH RuntimeOperationCoordinator lifecycle')

# 5) Accessibility target-loss and live telemetry wiring.
svc = require('app/src/main/java/com/althmany/extractor/accessibility/WhatsAppAccessibilityService.kt')
x = svc.read_text(encoding='utf-8')
anchor = 'import com.althmany.extractor.profile.WhatsAppInstanceRegistry\n'
for imp in [
    'import com.althmany.extractor.profile.UnifiedRuntimeTargetStore\n',
    'import com.althmany.extractor.runtime.RuntimeTelemetryBridge\n',
    'import com.althmany.extractor.runtime.recovery.TargetRecoveryCoordinator\n',
]:
    if imp not in x:
        if anchor not in x:
            raise SystemExit('Accessibility import anchor missing')
        x = x.replace(anchor, anchor + imp)
needle = '''        packageName?.let { runCatching { ProfileAccessibilityRuntime.recordEvent(this, it) } }
        attachControllersSafely("event")
'''
replacement = '''        packageName?.let { runCatching { ProfileAccessibilityRuntime.recordEvent(this, it) } }
        val expectedPackage = UnifiedRuntimeTargetStore.selectedPackage(this)
        RuntimeTelemetryBridge.recordTarget(expectedPackage, packageName)
        TargetRecoveryCoordinator.onAccessibilityPackage(this, packageName)
        attachControllersSafely("event")
'''
if 'RuntimeTelemetryBridge.recordTarget(expectedPackage, packageName)' not in x:
    if needle not in x:
        raise SystemExit('Accessibility event hook anchor missing')
    x = x.replace(needle, replacement)
needle2 = '''                val pkg = root?.packageName?.toString()
                if (WhatsAppInstanceRegistry.isSupportedPackage(pkg)) {
'''
replacement2 = '''                val pkg = root?.packageName?.toString()
                val expectedPackage = UnifiedRuntimeTargetStore.selectedPackage(this@WhatsAppAccessibilityService)
                RuntimeTelemetryBridge.recordTarget(expectedPackage, pkg)
                TargetRecoveryCoordinator.onAccessibilityPackage(this@WhatsAppAccessibilityService, pkg)
                if (WhatsAppInstanceRegistry.isSupportedPackage(pkg)) {
'''
if 'TargetRecoveryCoordinator.onAccessibilityPackage(this@WhatsAppAccessibilityService, pkg)' not in x:
    if needle2 not in x:
        raise SystemExit('Accessibility poll hook anchor missing')
    x = x.replace(needle2, replacement2)
svc.write_text(x, encoding='utf-8')
print('PATCH Accessibility telemetry/recovery')

# 6) Shizuku central snapshots: real observed package + signature + latency feed recovery/health.
shui = require('app/src/main/java/com/althmany/extractor/shizuku/ShizukuUiRuntime.kt')
u = shui.read_text(encoding='utf-8')
anchor = 'import android.graphics.Rect\n'
for imp in [
    'import android.os.SystemClock\n',
    'import com.althmany.extractor.runtime.RuntimeTelemetryBridge\n',
    'import com.althmany.extractor.runtime.recovery.TargetRecoveryCoordinator\n',
]:
    if imp not in u:
        if anchor not in u:
            raise SystemExit('ShizukuUiRuntime import anchor missing')
        u = u.replace(anchor, anchor + imp)
old_snapshot = '    suspend fun snapshot(packageName: String): ShizukuUiTree = parse(ShizukuBridge.fastSnapshot(context, packageName))\n'
new_snapshot = '''    suspend fun snapshot(packageName: String): ShizukuUiTree {
        val started = SystemClock.elapsedRealtime()
        val tree = parse(ShizukuBridge.fastSnapshot(context, packageName))
        val latency = (SystemClock.elapsedRealtime() - started).coerceAtLeast(0L)
        RuntimeTelemetryBridge.recordSnapshot(
            expectedPackage = packageName,
            observedPackage = tree.rootPackage,
            signature = tree.signature.toString(),
            latencyMs = latency
        )
        TargetRecoveryCoordinator.onShizukuSnapshot(context, tree.rootPackage, tree.signature)
        return tree
    }
'''
if 'TargetRecoveryCoordinator.onShizukuSnapshot(context, tree.rootPackage, tree.signature)' not in u:
    if old_snapshot not in u:
        raise SystemExit('ShizukuUiRuntime snapshot anchor missing')
    u = u.replace(old_snapshot, new_snapshot)
old_wait = '''    suspend fun waitFrame(packageName: String, sequence: Long, timeoutMs: Int): Pair<Long, ShizukuUiTree> {
        val frame = ShizukuBridge.waitAndSnapshot(context, packageName, sequence, timeoutMs, 1500)
        return frame.sequence to parse(frame.result)
    }
'''
new_wait = '''    suspend fun waitFrame(packageName: String, sequence: Long, timeoutMs: Int): Pair<Long, ShizukuUiTree> {
        val started = SystemClock.elapsedRealtime()
        val frame = ShizukuBridge.waitAndSnapshot(context, packageName, sequence, timeoutMs, 1500)
        val tree = parse(frame.result)
        val latency = (SystemClock.elapsedRealtime() - started).coerceAtLeast(0L)
        RuntimeTelemetryBridge.recordSnapshot(
            expectedPackage = packageName,
            observedPackage = tree.rootPackage,
            signature = tree.signature.toString(),
            latencyMs = latency
        )
        TargetRecoveryCoordinator.onShizukuSnapshot(context, tree.rootPackage, tree.signature)
        return frame.sequence to tree
    }
'''
if old_wait in u:
    u = u.replace(old_wait, new_wait)
shui.write_text(u, encoding='utf-8')
print('PATCH Shizuku snapshots telemetry/recovery')

# 7) Shizuku command-dump circuit breaker: 12s hard-failure cooldown + throttled cooldown journal.
shsvc = require('app/src/main/java/com/althmany/groupmanager/shizuku/ShizukuAutomationService.kt')
q = shsvc.read_text(encoding='utf-8')
q = q.replace('private const val COMMAND_DUMP_KILL_COOLDOWN_MS = 1_000L',
              'private const val COMMAND_DUMP_KILL_COOLDOWN_MS = 12_000L')
if 'private var lastCommandDumpCooldownLogAtElapsed' not in q:
    field_anchor = 'private var lastDumpFailureCountedAtElapsed = 0L\n'
    if field_anchor in q:
        q = q.replace(field_anchor, field_anchor + '    private var lastCommandDumpCooldownLogAtElapsed = 0L\n')
# Prevent successful reset/rebind from prematurely clearing a hard-kill circuit if old source does so.
q = q.replace('commandDumpSuppressedUntilElapsed = 0L\n',
              'commandDumpSuppressedUntilElapsed = maxOf(commandDumpSuppressedUntilElapsed, android.os.SystemClock.elapsedRealtime() + COMMAND_DUMP_KILL_COOLDOWN_MS)\n')
shsvc.write_text(q, encoding='utf-8')
print('PATCH Shizuku command-dump hard cooldown')

# 8) Conservative adaptive timing integration (Phase 6) — no new executor and no retry bypass.
def patch_controller(path, import_lines, replacements):
    p = require(path)
    text = p.read_text(encoding='utf-8')
    package_end = text.find('\n', text.find('package '))
    for imp in import_lines:
        if imp not in text:
            text = text[:package_end+1] + imp + '\n' + text[package_end+1:]
            package_end = text.find('\n', text.find('package '))
    for old, new in replacements:
        if old in text:
            text = text.replace(old, new)
    p.write_text(text, encoding='utf-8')

perf_imp = ['import com.althmany.extractor.engine.performance.AdaptiveRuntimeBridge']
patch_controller(
    'app/src/main/java/com/althmany/extractor/engine/PublishController.kt',
    perf_imp,
    [
        ('delay(_state.value.speed.settleMs.coerceAtMost(90L))',
         'delay(minOf(_state.value.speed.settleMs.coerceAtMost(90L), AdaptiveRuntimeBridge.publishTiming().pollDelayMs))'),
        ('awaitEventOrDelay(70L)',
         'awaitEventOrDelay(AdaptiveRuntimeBridge.publishTiming().verifyDelayMs.coerceAtMost(220L))'),
    ]
)
patch_controller(
    'app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt',
    perf_imp,
    [
        ('withTimeoutOrNull(220L) { uiEvents.first() }\n            delay(20L)',
         'withTimeoutOrNull(AdaptiveRuntimeBridge.extractionTiming().verifyDelayMs.coerceAtLeast(120L)) { uiEvents.first() }\n            delay(AdaptiveRuntimeBridge.extractionTiming().pollDelayMs.coerceAtMost(180L))'),
    ]
)
patch_controller(
    'app/src/main/java/com/althmany/extractor/engine/ScanController.kt',
    perf_imp,
    [
        ('delay(ScanRetryPolicy.backoffMs(d.status, attempt, speed))',
         'delay(maxOf(ScanRetryPolicy.backoffMs(d.status, attempt, speed), AdaptiveRuntimeBridge.scanTiming().actionDelayMs))'),
    ]
)
print('PATCH controller adaptive timing')

# 9) Diagnostics live-health panel and dynamic version header.
diag = require('app/src/main/java/com/althmany/extractor/ui/V341DiagnosticsScreen.kt')
d = diag.read_text(encoding='utf-8')
anchor = 'import com.althmany.extractor.engine.RuntimeOperationCoordinator\n'
for imp in [
    'import com.althmany.extractor.engine.health.SmartRuntimeLiveHealth\n',
    'import com.althmany.extractor.engine.performance.RuntimePerformanceOwner\n',
]:
    if imp not in d:
        if anchor not in d:
            raise SystemExit('Diagnostics import anchor missing')
        d = d.replace(anchor, anchor + imp)
d = d.replace('appendLine("AL-thmany 3.4.1 Runtime Diagnostic")',
              'appendLine("AL-thmany ${com.althmany.groupmanager.BuildConfig.VERSION_NAME} Smart Runtime Diagnostic")')
d = d.replace('com.althmany.extractor.BuildConfig.VERSION_NAME',
              'com.althmany.groupmanager.BuildConfig.VERSION_NAME')
journal = '            item {\n                DCard {\n                    DTitle("سجل Runtime الأخير")'
if journal in d and 'SmartRuntimeHealthPanel(rows)' not in d:
    panel = '''            item {
                val autoMode = snapshot.runtimeBackend.startsWith("AUTO")
                val rows = listOf(
                    RuntimePerformanceOwner.SCAN,
                    RuntimePerformanceOwner.EXTRACTION,
                    RuntimePerformanceOwner.PUBLISH
                ).map {
                    SmartRuntimeLiveHealth.capture(
                        owner = it,
                        preferenceAuto = autoMode,
                        alternateBackendReady = snapshot.accessibilityConnected || snapshot.shizukuReady
                    )
                }
                SmartRuntimeHealthPanel(rows)
            }

'''
    d = d.replace(journal, panel + journal)
diag.write_text(d, encoding='utf-8')
print('PATCH diagnostics live health')

# 10) Version 4.0 while preserving debug applicationId/version suffix for smoke builds.
gradle = require('app/build.gradle.kts')
g = gradle.read_text(encoding='utf-8')
g = re.sub(r'versionCode\s*=\s*\d+', 'versionCode = 600', g, count=1)
g = re.sub(r'versionName\s*=\s*"[^"]+"', 'versionName = "4.0"', g, count=1)
gradle.write_text(g, encoding='utf-8')
print('PATCH version 4.0 / code 600; debug suffix preserved')

print('PHASE9_INTEGRATION_APPLIED')
