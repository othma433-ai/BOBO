# AL-thmany 4.0 — Phase 9 Integration Conflict Audit

## Canonical merge decisions

- Phase 2 runtime classes supersede duplicate Phase 1 runtime class copies.
- Phase 4 `RuntimeControlRouter` supersedes Phase 3 router, then Phase 9 replaces it with a command-bus gateway implementation.
- Phase 5–8 remain additive under `engine/performance`, `engine/health`, and UI diagnostics.

## Integration defects found and corrected

1. **Phase 5 compile defect** — `TelemetryWindow` used `ArrayDeque.addLast()` which failed under the project Kotlin toolchain used for the integration smoke. Replaced with compatible `add()`.
2. **Overlay bypassed RuntimeCommandBus** — Phase 3/4 controls invoked controllers directly. Phase 9 adds `SmartRuntimeKernel` and routes public Pause/Resume/Stop/Return commands through `RuntimeCommandBus` first.
3. **Command dedupe could become permanent** — identical commands could be rejected indefinitely until a different command/reset. Phase 9 changes this to a 250 ms tap-debounce window so retrying Return/Resume remains possible.
4. **Floating controls were not truly active-operation lifecycle driven** — Phase 9 binds start/stop to the single `RuntimeOperationCoordinator` owner through `SmartRuntimeLifecycle`.
5. **Notification fallback had no controls** — Phase 9 adds Pause/Resume/Return/Stop notification actions even when overlay permission is unavailable.
6. **Remote Shizuku target loss did not actually pause** — Phase 9 makes central Shizuku snapshots feed the target-loss supervisor and pauses the current owner after confirmed loss.
7. **Remote Resume could deadlock on unchanged UI text** — Phase 9 accepts a newer verified snapshot generation as freshness proof even if the content signature is unchanged, while still requiring the exact target package.
8. **Shizuku snapshot telemetry was not wired** — Phase 9 records real snapshot latency, package visibility and signature through a central telemetry bridge.
9. **Accessibility target visibility telemetry was not wired** — Phase 9 reports all package/root changes, including non-WhatsApp frames, into telemetry and recovery.
10. **Process recreation behavior was unsafe/incomplete** — Phase 9 restores ownership metadata only and marks `processRecoveryRequired`; it does not blindly restart UI input after process death.
11. **Diagnostics BuildConfig namespace was wrong in earlier overlay** — actual Android namespace is `com.althmany.groupmanager`; Phase 9 uses `com.althmany.groupmanager.BuildConfig.VERSION_NAME`.
12. **Smoke package isolation preserved** — version is moved to `4.0` / code `600`, but existing debug `applicationIdSuffix = ".debug"` and `versionNameSuffix = "-debug"` are intentionally preserved.

## Verification completed locally

- Phase 9 pure runtime/performance/health Kotlin compile: PASS.
- Runtime core behavioral smoke: PASS.
- Target-loss/resume freshness state-machine compile: PASS.
- Remote same-content/new-generation resume smoke: PASS.
- Installer mock application: PASS.
- Installer repeated application/idempotence checks: PASS.
- Debug package suffix preservation check: PASS.

## Not yet verified

- Full Android Gradle `testDebugUnitTest` on the real repository.
- Full Android `assembleDebug` on the real repository.
- Exact APK smoke on device.
- Work Profile / Secure Folder / Dual Messenger device matrix.

Those require applying this integration overlay to the development branch/worktree and running CI/device tests.
