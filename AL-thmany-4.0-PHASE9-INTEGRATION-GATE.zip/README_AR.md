# AL-thmany 4.0 — Phase 9 Integration Gate

هذه ليست Phase صغيرة جديدة؛ إنها حزمة دمج وتصحيح لـ Phases 1–8 قبل بناء APK.

## أهم ما تغيّر

- توحيد التحكم العام عبر `SmartRuntimeKernel` + `RuntimeCommandBus`.
- ربط Floating Controls بدورة حياة `RuntimeOperationCoordinator` الحقيقية.
- Notification fallback أصبح يحتوي Pause / Resume / Return / Stop.
- إصلاح Remote Shizuku target-loss pause.
- إصلاح Smart Resume حتى لا يعلق إذا رجع المستخدم إلى نفس شاشة واتساب ولم يتغير النص.
- توصيل Telemetry الفعلية من Accessibility وShizuku.
- إصلاح Compile error حقيقي في `TelemetryWindow`.
- جعل process recreation آمنًا: RECOVERY_REQUIRED بدل إعادة النقر تلقائيًا.
- تصحيح BuildConfig namespace إلى `com.althmany.groupmanager`.
- الإصدار: `4.0`، versionCode `600`، مع الحفاظ على `.debug` أثناء smoke tests.

## التثبيت على نسخة مستودع محلية

```bash
python scripts/install_phase9_integration.py /path/to/BOBO
```

ثم:

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

لا تعتبر النسخة Release Candidate قبل نجاح الاختبارات وتجربة APK على الجهاز.
