# Runtime Unified v3 — ملخص الإصلاحات

- إصلاح منطق الانتقال بعد الحالات النهائية في Join: Single-Flight + Auto-advance، وعدم إيقاف التشغيل بسبب X/Back المملوك للمحرك.
- تفعيل Auto Resume للانتقالات التي ينفذها المحرك بدل انتظار Resume يدوي.
- توحيد عدد المحاولات إلى محاولة واحدة في Join / Scan / Publish وإزالة إعدادات إعادة المحاولة من الواجهة الأساسية.
- تسريع Accessibility event routing وإضافة scroll/text-change events.
- توسيع اكتشاف نسخ WhatsApp محليًا وديناميكيًا، وإضافة probing صريح لـ Samsung Dual Messenger user 95 وبيئات شائعة أخرى عبر Shizuku.
- إضافة نمط عرض 4 أسطر + عرض المزيد للنصوص الطويلة في واجهة الفحص.
- الحفاظ على RTL في Compose وتحسين theme typography العربي.

- فصل اختيار Accessibility وShizuku في الواجهة: لا يوجد Auto ظاهر؛ كل محرك يمكن اختياره وتشغيله مستقلًا، والهدف البعيد يفرض Shizuku فقط.
