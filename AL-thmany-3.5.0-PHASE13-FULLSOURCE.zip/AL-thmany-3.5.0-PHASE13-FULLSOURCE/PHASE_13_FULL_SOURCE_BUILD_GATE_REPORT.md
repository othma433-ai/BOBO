# Phase 13 — Full-Source Rebuild & Build Gate

## Root cause discovered
The earlier staged `*.patch` files were not valid unified diffs. A direct `patch -p1` reproduction rejected **39/39** with:

`Only garbage was found in the patch input.`

Therefore Phase 13 stopped treating those files as deployable patches and rebuilt the candidate as **full source files**.

## Full-source reconciliation
The Phase 13 source candidate contains the integrated scan/runtime/database/export work directly in the Kotlin source tree. It does not depend on the invalid patch files.

Key reconciliation points:
- DB schema version 12 and `visible_member_indicator`
- `EXPIRED` classification
- strict `PENDING_ONLY`
- persistent resume semantics
- fast two-snapshot scan policy
- stale-screen freshness protection
- same-item runtime recovery
- notification throttling / batched stats
- scan path forced to `SCAN_ONLY`
- scan hot path does not invoke Join / Request-to-Join actions

## Verification actually executed
- `git diff --check`: PASS
- conflict-marker scan: PASS
- pure Kotlin scan-core compilation with `kotlinc`: PASS
- executable core behavior harness: **PHASE13_CORE_HARNESS_PASS**
- structural integration assertions: 13/13 PASS

## Android build gate
A complete Android `test` / `assembleDebug` could not be executed in this environment because:
- no Android SDK is installed or configured;
- no system Gradle installation is present;
- the local source baseline does not contain the Gradle wrapper files.

This is therefore a **full-source build candidate**, not a verified APK.

## GitHub status
No GitHub files were modified or pushed.

## Required release gate
Run on a machine/CI with Android SDK + Gradle wrapper:
1. `./gradlew test`
2. `./gradlew assembleDebug`
3. fix any compiler/test failures
4. device smoke test with Accessibility and Shizuku
5. only then publish/push the combined release
