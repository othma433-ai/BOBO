# Runtime Unified v3 — Verification

## Root cause from provided diagnostic
- The Join runtime was configured with `autoPauseOutsideWhatsApp=true` and `autoResumeCurrentRun=false`.
- Controlled X/Back transitions could therefore be interpreted as leaving WhatsApp and park the queue.
- A stale terminal screen could continue to be classified after another observer had already advanced the repository queue.
- The app had two separate Accessibility services; extractor/scan/publish depended on a different concrete service than Join.

## Implemented controls
- Join/Scan/Publish are Single-Flight (one attempt per task).
- Controlled X/Back does not auto-pause the Join run; auto-resume is enabled for controlled handoff.
- Stale terminal handoff invalidates cache and reloads the current queue item.
- Join Accessibility service implements the shared `AccessibilityUiDriver` and can drive Extraction/Scan/Publish.
- Accessibility and Shizuku are shown as separate explicit backend choices; remote Android-user targets require Shizuku.
- Samsung Dual Messenger user 95 is proactively probed; additional WhatsApp-like packages are dynamically discovered.
- Scan/result long text is collapsed to four lines with “عرض المزيد”.

## Verification executed
- `scripts/run_pure_kotlin_regressions.sh` — PASS
- `scripts/run_integrated_extractor_pure_checks.sh` — PASS
- `scripts/validate_integrated_extractor.py` — PASS
- `scripts/validate_smart_extraction_ui.py` — PASS
- `scripts/validate_unified_runtime_v341.py` — PASS
- `scripts/validate_source.py` — PASS
- `scripts/validate_runtime_unified_v3.py` — PASS
- `RuntimeUnifiedPolicyChecks.kt` — PASS

## Known pre-existing validator issue
`validate_full_features_3_4_1.py` reports `join route` and `scan route` failures in both the original source and this modified source, so those two checks are pre-existing validator mismatches rather than regressions introduced here.

## Build note
The supplied source tree does not include a Gradle wrapper and the execution environment has no system Gradle installation, so a full Android APK compile was not available in this environment. Source/pure-Kotlin/static contracts above were verified.
