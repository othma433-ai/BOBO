# AL-thmany 3.4.1 — Runtime Core Unified v6

## التصحيحات المنفذة

1. **إزالة Retry القديم من Extraction بالكامل**
   - حذف `setExtractionRetries` من AppViewModel.
   - حذف `setMaxSameGroupRetries` من Controller وSettings store.
   - حذف `maxSameGroupRetries` من `ExtractionPreferences` و`ExtractionUiState`.
   - إزالة حلقة retry الفعلية من مسار Shizuku؛ كل قروب Single-Flight واحد في الدورة الحالية.
   - الفشل يسجل `FAILED` ليبقى قابلاً للمعالجة في تشغيل لاحق بدل إعادة نفس القروب مباشرة.

2. **إزالة واجهة Scan القديمة**
   - حذف `V341ScanScreen` غير المستخدم.
   - إزالة استيراده من MainActivity.
   - المسار الفعلي الوحيد للفحص هو `ProfessionalScanScreen`، ومحرك Scan يفرض `SCAN_ONLY`.

3. **Repository واحد لإعدادات Runtime العامة**
   - إضافة `UnifiedRuntimeRepository` كواجهة عامة موحدة لـ backend / target / profile / speed.
   - ترحيل المستهلكين الرئيسيين: Join / Scan / Extraction / Publish / AppViewModel / ExtractorApp / Diagnostics / NativeProfileEngineRouter.
   - Feature-specific settings تبقى منفصلة فقط للخيارات الوظيفية الخاصة بكل خاصية.

4. **تنظيف واجهة Settings**
   - إزالة خيارات إعادة المحاولة الميتة.
   - إزالة callbacks غير المستخدمة لمحاولات Scan/Publish من Settings العامة.
   - إبقاء Single-Flight كسياسة قراءة فقط بدل خيار قابل للتعديل.

## التحقق

تم تشغيل ونجاح:
- `run_pure_kotlin_regressions.sh`
- `validate_integrated_extractor.py`
- `validate_smart_extraction_ui.py`
- `validate_unified_runtime_v341.py`
- `validate_runtime_core_unified_v5.py`
- `validate_source.py`
- `validate_runtime_cleanup_v6.py`

> ملاحظة: هذه تحققّات Source-level وPure Kotlin. لم يتم Android APK compile في هذه البيئة.
