package com.althmany.extractor.engine

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import com.althmany.extractor.accessibility.AccessibilityRuntimeBridge
import com.althmany.extractor.accessibility.AccessibilityUiDriver
import com.althmany.extractor.data.ExtractorRepository
import com.althmany.extractor.data.InviteKind
import com.althmany.extractor.data.ScanRecord
import com.althmany.extractor.data.ScanStatus
import com.althmany.extractor.profile.WhatsAppInstanceRegistry
import com.althmany.extractor.profile.RuntimeBackendPreference
import com.althmany.extractor.profile.RuntimeBackendKind
import com.althmany.extractor.profile.UnifiedRuntimeRepository
import com.althmany.extractor.shizuku.ShizukuBridge
import com.althmany.extractor.shizuku.ShizukuUiRuntime
import com.althmany.extractor.shizuku.ShizukuUiTree
import com.althmany.extractor.notification.ScanNotifier
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * WhatsApp invite scanner. Read-only by design; Join owns all membership actions.
 *
 * Guarantees by design:
 *  - scan never clicks Join / Request to Join;
 *  - launches only the explicitly selected WhatsApp package;
 *  - retries only uncertain/transient outcomes;
 *  - stores confidence, signal, metadata and duration for auditability;
 *  - interrupted SCANNING rows are returned to PENDING on the next run.
 */
object ScanController {
    private lateinit var appContext: Context
    private lateinit var repository: ExtractorRepository
    private lateinit var settingsStore: ScanSettingsStore
    private lateinit var notifier: ScanNotifier
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val uiEvents = MutableSharedFlow<Unit>(replay = 0, extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    private val adapter = WhatsAppUiAdapter()
    private val shizukuUi: ShizukuUiRuntime by lazy { ShizukuUiRuntime(appContext) }
    @Volatile private var shizukuMode = false
    @Volatile private var effectiveScanBackend: RuntimeBackendKind = RuntimeBackendKind.NONE
    @Volatile private var uiEventGeneration: Long = 0L
    @Volatile private var recoveryInProgress = false
    @Volatile private var lastProgressNotificationMs: Long = 0L
    private var service: AccessibilityUiDriver? = null
    private var job: Job? = null
    @Volatile private var pauseRequested = false
    private const val POST_ACTION_GRACE_MS = 650L
    private const val MAX_POSITIVE_FOLLOW_UPS = 2

    private val _state = MutableStateFlow(ScanUiState())
    val state: StateFlow<ScanUiState> = _state.asStateFlow()

    fun initialize(context: Context, repo: ExtractorRepository) {
        appContext = context.applicationContext
        repository = repo
        settingsStore = ScanSettingsStore(appContext)
        notifier = ScanNotifier(appContext)
        _state.value = _state.value.copy(
            speed = settingsStore.loadSpeed(),
            scope = settingsStore.loadScope(),
            maxAttempts = settingsStore.loadMaxAttempts(),
            actionMode = settingsStore.loadActionMode(),
            requestToJoinEnabled = settingsStore.loadRequestToJoinEnabled()
        )
        refreshStats()
    }

    fun attachService(value: AccessibilityUiDriver) {
        service = value
        _state.value = _state.value.copy(serviceConnected = true)
    }

    fun detachService(value: AccessibilityUiDriver) {
        if (service === value) service = null
        _state.value = _state.value.copy(serviceConnected = false)
    }

    fun notifyUiEvent(packageName: CharSequence?) {
        val observed = packageName?.toString() ?: return
        val expected = ExtractionController.state.value.selectedWhatsAppPackage ?: return
        if (observed == expected) {
            uiEventGeneration += 1L
            uiEvents.tryEmit(Unit)
        }
    }

    private fun recoverLiveService(): AccessibilityUiDriver? {
        val live = service ?: AccessibilityRuntimeBridge.currentEvenIfQuiet()
        if (live != null && service !== live) attachService(live)
        return live
    }

    private suspend fun ensureRuntimeReady(timeoutMs: Long = 8_500L): Boolean {
        val packageName = ExtractionController.state.value.selectedWhatsAppPackage ?: run {
            _state.value = _state.value.copy(message = "RUNTIME_NO_TARGET: اختر نسخة واتساب أولاً")
            return false
        }
        val preference = UnifiedRuntimeRepository.preference(appContext)
        val runtimeTarget = UnifiedRuntimeRepository.resolve(appContext, packageName)
        val sh = runCatching { ShizukuBridge.status() }.getOrNull()

        val opened = when (preference) {
            RuntimeBackendPreference.SHIZUKU -> {
                if (sh?.ready != true) {
                    _state.value = _state.value.copy(
                        message = "SHIZUKU_NOT_READY: المحرك محدد على Shizuku لكنه غير جاهز"
                    )
                    return false
                }
                ShizukuBridge.launchPackage(appContext, packageName, runtimeTarget.targetAndroidUserId)
            }
            RuntimeBackendPreference.ACCESSIBILITY -> ExtractionController.openWhatsApp()
            RuntimeBackendPreference.AUTO ->
                ExtractionController.openWhatsApp() ||
                    (sh?.ready == true && ShizukuBridge.launchPackage(appContext, packageName, runtimeTarget.targetAndroidUserId))
        }

        if (!opened) {
            _state.value = _state.value.copy(
                message = "RUNTIME_OPEN_FAILED: تعذر فتح نسخة واتساب المحددة"
            )
            return false
        }

        // Do not spend the Accessibility grace window when AUTO already resolved to Shizuku.
        if (runtimeTarget.effectiveBackend == com.althmany.extractor.profile.RuntimeBackendKind.ACCESSIBILITY &&
            !runtimeTarget.remoteTarget
        ) {
            val accessDeadline = SystemClock.elapsedRealtime() + minOf(timeoutMs, 1_800L)
            while (SystemClock.elapsedRealtime() < accessDeadline) {
                val live = recoverLiveService()
                if (live != null && adapter.isWhatsAppRoot(live.currentRoot(), packageName)) {
                    shizukuMode = false
                    effectiveScanBackend = RuntimeBackendKind.ACCESSIBILITY
                    _state.value = _state.value.copy(
                        message = "READY_ACCESSIBILITY: الفحص يرى واتساب عبر Accessibility"
                    )
                    return true
                }
                withTimeoutOrNull(150L) { uiEvents.first() }
                delay(20L)
            }
            if (preference == RuntimeBackendPreference.ACCESSIBILITY) {
                shizukuMode = false
                _state.value = _state.value.copy(
                    message = "ACCESSIBILITY_ROOT_NOT_READY: Accessibility محددة لكن لا ترى واتساب المستهدف"
                )
                return false
            }
        }

        if (sh?.ready == true) {
            if (!ShizukuBridge.ensureBound(appContext, 4_500L)) {
                _state.value = _state.value.copy(
                    message = "SHIZUKU_BIND_FAILED: الإذن موجود لكن UserService لم يرتبط"
                )
                shizukuMode = false
                return false
            }

            ShizukuBridge.launchPackage(appContext, packageName, runtimeTarget.targetAndroidUserId)
            var lastDetail = "NO_SNAPSHOT"
            var resetTried = false
            val deadline = SystemClock.elapsedRealtime() + (timeoutMs - 1_800L).coerceAtLeast(5_000L)
            while (SystemClock.elapsedRealtime() < deadline) {
                val tree = shizukuUi.snapshot(packageName)
                lastDetail = "${tree.state}:${tree.detail.take(140)}"
                if (tree.state == "OK" && tree.nodes.isNotEmpty() && shizukuUi.isWhatsApp(tree, packageName)) {
                    shizukuMode = true
                    effectiveScanBackend = RuntimeBackendKind.SHIZUKU
                    _state.value = _state.value.copy(
                        message = "READY_SHIZUKU: الفحص يرى واتساب عبر Shizuku (${tree.nodes.size} node)"
                    )
                    return true
                }
                if (!resetTried && tree.state in setOf("UNAVAILABLE", "ERROR", "NO_ROOT")) {
                    resetTried = true
                    ShizukuBridge.reset(appContext)
                    ShizukuBridge.launchPackage(appContext, packageName, runtimeTarget.targetAndroidUserId)
                }
                delay(110L)
            }
            _state.value = _state.value.copy(message = "SHIZUKU_UI_NOT_READY: $lastDetail")
        } else {
            _state.value = _state.value.copy(
                message = when {
                    sh == null || !sh.binderAlive -> "SHIZUKU_BINDER_OFF: شغّل Shizuku"
                    !sh.permissionGranted -> "SHIZUKU_PERMISSION_DENIED: امنح التطبيق إذن Shizuku"
                    else -> "RUNTIME_NO_BACKEND: لا يوجد محرك تحكم جاهز"
                }
            )
        }

        shizukuMode = false
        effectiveScanBackend = RuntimeBackendKind.NONE
        return false
    }

    fun isRunning(): Boolean = job?.isActive == true

    fun setSpeed(value: ScanSpeedProfile) {
        if (isRunning()) return
        settingsStore.saveSpeed(value)
        _state.value = _state.value.copy(speed = value)
    }

    fun setScope(value: ScanScope) {
        if (isRunning()) return
        settingsStore.saveScope(value)
        _state.value = _state.value.copy(scope = value)
    }

    fun setMaxAttempts(value: Int) {
        if (isRunning()) return
        settingsStore.saveMaxAttempts(1)
        _state.value = _state.value.copy(maxAttempts = 1)
    }

    fun setActionMode(value: ScanActionMode) {
        if (isRunning()) return
        settingsStore.saveActionMode(ScanActionMode.SCAN_ONLY)
        _state.value = _state.value.copy(actionMode = ScanActionMode.SCAN_ONLY)
    }

    fun setRequestToJoinEnabled(value: Boolean) {
        if (isRunning()) return
        settingsStore.saveRequestToJoinEnabled(false)
        _state.value = _state.value.copy(requestToJoinEnabled = false)
    }

    fun start() {
        if (job?.isActive == true) return
        // Scan is permanently read-only and single-pass in the unified 3.4.1 workspace.
        // Old persisted UI preferences cannot make a new scan slower or repeat the same URL.
        setActionMode(ScanActionMode.SCAN_ONLY)
        setRequestToJoinEnabled(false)
        setMaxAttempts(1)
        if (SenderRuntimeGuard.isSenderRunning(appContext)) {
            _state.value = _state.value.copy(status = ScanEngineStatus.ERROR, message = "أوقف تشغيل Sender الحالي أولاً قبل تشغيل الفحص")
            return
        }
        if (ExtractionController.isBusy() || PublishController.isRunning()) {
            _state.value = _state.value.copy(status = ScanEngineStatus.ERROR, message = "أوقف الاستخراج أو النشر أولاً قبل تشغيل الفحص")
            return
        }
        if (ExtractionController.state.value.selectedWhatsAppPackage == null) {
            _state.value = _state.value.copy(status = ScanEngineStatus.ERROR, message = "اختر نسخة واتساب أولاً")
            return
        }
        if (!RuntimeOperationCoordinator.tryAcquire(RuntimeOperation.SCAN)) {
            val owner = RuntimeOperationCoordinator.current()?.labelAr ?: "عملية أخرى"
            _state.value = _state.value.copy(status = ScanEngineStatus.ERROR, message = "لا يمكن بدء الفحص أثناء تشغيل $owner")
            return
        }
        pauseRequested = false
        job = scope.launch { runScan() }.also { activeJob ->
            activeJob.invokeOnCompletion { RuntimeOperationCoordinator.release(RuntimeOperation.SCAN) }
        }
    }

    fun pause() {
        if (job?.isActive != true) return
        pauseRequested = true
        _state.value = _state.value.copy(status = ScanEngineStatus.PAUSED, paused = true, message = "الفحص متوقف مؤقتًا")
        notifier.show(_state.value)
    }

    fun resume() {
        if (job?.isActive != true) return
        pauseRequested = false
        _state.value = _state.value.copy(status = ScanEngineStatus.CLASSIFYING, paused = false, message = "استكمال الفحص")
        notifier.show(_state.value)
    }

    fun stop() {
        job?.cancel()
        job = null
        RuntimeOperationCoordinator.release(RuntimeOperation.SCAN)
        pauseRequested = false
        _state.value = _state.value.copy(
            status = ScanEngineStatus.STOPPED,
            running = false,
            paused = false,
            currentUrl = null,
            currentAttempt = 0,
            message = "تم إيقاف الفحص — يمكن بدءه لاحقًا لاستكمال العناصر غير المكتملة"
        )
        notifier.cancel()
        refreshStats()
    }

    fun refreshStats() {
        if (!::repository.isInitialized) return
        scope.launch {
            val stats = kotlinx.coroutines.withContext(Dispatchers.IO) { repository.scanStats() }
            _state.value = _state.value.copy(stats = stats)
        }
    }

    private suspend fun runScan() {
        try {
            repository.resetScanRunningItems()
            val configuredScope = _state.value.scope
            val preflightScope = if (configuredScope == ScanScope.RECHECK_ALL) ScanScope.PENDING_ONLY else configuredScope
            if (configuredScope != ScanScope.RECHECK_ALL && repository.scanItemsForScope(preflightScope).isEmpty()) {
                _state.value = _state.value.copy(
                    status = ScanEngineStatus.COMPLETED,
                    running = false,
                    message = "NO_SCAN_ITEMS: أضف روابط للفحص أولاً"
                )
                refreshStats()
                return
            }
            if (!ensureRuntimeReady()) {
                val detail = _state.value.message
                _state.value = _state.value.copy(
                    status = ScanEngineStatus.ERROR,
                    running = false,
                    message = if (detail.isBlank()) "RUNTIME_NOT_READY: تعذر تجهيز محرك الفحص" else detail
                )
                return
            }
            val scanScope = if (configuredScope == ScanScope.RECHECK_ALL) {
                // RECHECK_ALL is a one-shot command. Convert it to PENDING_ONLY immediately after
                // resetting so an interrupted job resumes from the remaining rows instead of
                // resetting the whole queue again on the next Start.
                repository.prepareRecheckAll()
                settingsStore.saveScope(ScanScope.PENDING_ONLY)
                _state.value = _state.value.copy(scope = ScanScope.PENDING_ONLY)
                ScanScope.PENDING_ONLY
            } else configuredScope
            val items = repository.scanItemsForScope(scanScope)
            if (items.isEmpty()) {
                _state.value = _state.value.copy(status = ScanEngineStatus.COMPLETED, running = false, message = "لا توجد روابط مطابقة لنطاق الفحص")
                refreshStats(); return
            }

            val speed = _state.value.speed
            val maxAttempts = 1
            _state.value = _state.value.copy(
                status = ScanEngineStatus.PREPARING,
                running = true,
                paused = false,
                total = items.size,
                currentIndex = 0,
                currentAttempt = 0,
                message = "تحضير ${items.size} رابط • ${configuredScope.labelAr} • ${speed.labelAr}"
            )
            notifier.show(_state.value)

            for ((index, item) in items.withIndex()) {
                waitIfPaused()
                awaitNetworkAvailability()
                var finalResult: TimedDecision? = null

                for (attempt in 1..maxAttempts) {
                    waitIfPaused()
                    _state.value = _state.value.copy(
                        status = ScanEngineStatus.OPENING,
                        running = true,
                        currentUrl = item.normalizedUrl,
                        currentIndex = index + 1,
                        total = items.size,
                        currentAttempt = attempt,
                        currentConfidence = 0,
                        message = "فحص ${index + 1}/${items.size} • محاولة $attempt/$maxAttempts"
                    )
                    maybeNotifyProgress()
                    repository.markScanAttempt(
                        id = item.id,
                        detail = "جارٍ الفحص — محاولة $attempt/$maxAttempts",
                        targetPackage = ExtractionController.state.value.selectedWhatsAppPackage
                    )

                    val result = scanOne(item, speed)
                    finalResult = result
                    val d = result.decision
                    _state.value = _state.value.copy(currentConfidence = d.confidence)

                    repository.updateScanResult(
                        id = item.id,
                        status = d.status,
                        groupName = d.groupName,
                        detail = d.detail,
                        incrementAttempt = false,
                        confidence = d.confidence,
                        memberCountText = d.memberCountText,
                        visibleMemberIndicator = d.visibleMemberIndicator,
                        inviteKind = d.inviteKind,
                        signalCode = d.signalCode,
                        durationMs = result.durationMs,
                        targetPackage = ExtractionController.state.value.selectedWhatsAppPackage
                    )
                    if (ScanHotLoopPolicy.shouldRefreshStats(index + 1, index == items.lastIndex)) refreshStats()

                    if (!ScanRetryPolicy.shouldRetry(d.status, attempt, maxAttempts)) break

                    _state.value = _state.value.copy(
                        status = ScanEngineStatus.RETRYING,
                        message = "${d.status.labelAr} — إعادة تحقق ذكية (${attempt + 1}/$maxAttempts)"
                    )
                    safelyReturnFromInvite(speed)
                    delay(ScanRetryPolicy.backoffMs(d.status, attempt, speed))
                }

                val last = finalResult?.decision
                if (last != null) {
                    _state.value = _state.value.copy(
                        message = "${last.status.labelAr} • ثقة ${last.confidence}%",
                        currentConfidence = last.confidence
                    )
                    maybeNotifyProgress()
                }
                // Stay inside WhatsApp and open the next invite directly.
            }

            _state.value = _state.value.copy(
                status = ScanEngineStatus.COMPLETED,
                running = false,
                paused = false,
                currentUrl = null,
                currentAttempt = 0,
                currentConfidence = 0,
                message = "اكتمل فحص الروابط"
            )
            notifier.show(_state.value, ongoing = false)
        } catch (c: CancellationException) {
            throw c
        } catch (t: Throwable) {
            _state.value = _state.value.copy(
                status = ScanEngineStatus.ERROR,
                running = false,
                paused = false,
                message = t.message ?: "تعذر إكمال الفحص"
            )
            notifier.show(_state.value, ongoing = false)
        } finally {
            job = null
            refreshStats()
        }
    }

    private data class TimedDecision(val decision: InviteScanDecision, val durationMs: Long)

    private suspend fun scanOne(item: ScanRecord, speed: ScanSpeedProfile): TimedDecision {
        if (shizukuMode) return scanOneShizuku(item, speed)
        val started = SystemClock.uptimeMillis()
        val packageName = ExtractionController.state.value.selectedWhatsAppPackage
            ?: return TimedDecision(
                InviteScanDecision(ScanStatus.ERROR, "لم يتم تحديد نسخة واتساب", true, 100, "NO_TARGET_PACKAGE"),
                0L
            )

        awaitNetworkAvailability()
        val preOpenGeneration = uiEventGeneration
        val preOpenSignature = currentAccessibilitySignature(packageName)
        if (!openInvite(item.normalizedUrl, packageName)) {
            return TimedDecision(
                InviteScanDecision(
                    ScanStatus.ERROR,
                    "تعذر فتح الرابط في ${WhatsAppInstanceRegistry.labelFor(packageName)}",
                    true,
                    100,
                    "LAUNCH_FAILED"
                ),
                SystemClock.uptimeMillis() - started
            )
        }

        _state.value = _state.value.copy(status = ScanEngineStatus.CLASSIFYING, message = "تحليل شاشة الدعوة")
        var deadline = SystemClock.uptimeMillis() + speed.previewTimeoutMs
        var last = InviteScanDecision(ScanStatus.UNKNOWN, "بانتظار ظهور حالة الدعوة", false, 0, "WAITING")
        var snapshotIndex = 0

        while (SystemClock.uptimeMillis() < deadline) {
            waitIfPaused()
            if (!isNetworkAvailable()) {
                _state.value = _state.value.copy(
                    status = ScanEngineStatus.WAITING_NETWORK,
                    message = "انقطع الاتصال — حفظ الرابط الحالي وانتظار رجوع الإنترنت"
                )
                awaitNetworkAvailability()
                // Re-process the exact same URL after connectivity returns. No result is committed
                // and the queue index is not advanced while the connection is unavailable.
                safelyReturnFromInvite(speed)
                if (!openInvite(item.normalizedUrl, packageName)) {
                    return TimedDecision(
                        InviteScanDecision(ScanStatus.ERROR, "عاد الاتصال لكن تعذر إعادة فتح نفس الرابط", true, 100, "REOPEN_FAILED"),
                        SystemClock.uptimeMillis() - started
                    )
                }
                snapshotIndex = 0
                last = InviteScanDecision(ScanStatus.UNKNOWN, "إعادة قراءة الرابط بعد عودة الاتصال", false, 0, "WAITING")
                deadline = SystemClock.uptimeMillis() + speed.previewTimeoutMs
                _state.value = _state.value.copy(status = ScanEngineStatus.CLASSIFYING, message = "عاد الاتصال — إعادة تحليل نفس الرابط")
            }
            val live = recoverLiveService()
            val root = live?.currentRoot()
            if (live == null || root == null || !adapter.isWhatsAppRoot(root, packageName)) {
                if (recoverRuntimeForCurrentItem(item, "ACCESSIBILITY_ROOT_LOST")) {
                    deadline = SystemClock.uptimeMillis() + speed.previewTimeoutMs
                    continue
                }
                return TimedDecision(
                    InviteScanDecision(
                        ScanStatus.UNKNOWN,
                        "تعذر استعادة محرك الفحص لنفس الرابط",
                        false,
                        0,
                        "RUNTIME_RECOVERY_FAILED"
                    ),
                    SystemClock.uptimeMillis() - started
                )
            }
            if (adapter.isWhatsAppRoot(root, packageName)) {
                val snap = adapter.snapshot(root)
                val candidateSignature = ScanScreenFreshnessGate.signature(snap.texts)
                if (!ScanScreenFreshnessGate.isFresh(
                        preOpenSignature,
                        candidateSignature,
                        uiEventGeneration > preOpenGeneration
                    )
                ) {
                    delay(ScanHotLoopPolicy.stalePollDelayMs)
                    continue
                }
                snapshotIndex += 1
                val decision = InviteScanClassifier.classify(snap.texts)
                last = chooseBetter(last, decision)
                _state.value = _state.value.copy(currentConfidence = last.confidence)
                when (FastContinuousScanPolicy.next(last, snapshotIndex)) {
                    FastScanAction.SAVE_AND_NEXT ->
                        return TimedDecision(last, SystemClock.uptimeMillis() - started)
                    FastScanAction.SHORT_VERIFY ->
                        delay(FastContinuousScanPolicy.shortVerifyDelayMs)
                    FastScanAction.SAVE_UNKNOWN_AND_NEXT ->
                        return TimedDecision(
                            last.copy(
                                status = ScanStatus.UNKNOWN,
                                detail = "لم تظهر إشارة مؤكدة بعد قراءتين سريعتين",
                                definitive = false,
                                signalCode = "FAST_UNKNOWN"
                            ),
                            SystemClock.uptimeMillis() - started
                        )
                }
            }
            withTimeoutOrNull(speed.eventWaitMs) { uiEvents.first() }
            delay(speed.settleDelayMs)
        }

        val final = last.copy(
            status = if (last.status == ScanStatus.UNKNOWN) ScanStatus.UNKNOWN else last.status,
            detail = if (last.status == ScanStatus.UNKNOWN) "لم تظهر علامة مؤكدة بعد انتظار شاشة مستقرة" else last.detail,
            definitive = true,
            signalCode = if (last.signalCode == "WAITING") "TIMEOUT_NO_SIGNAL" else last.signalCode
        )
        return TimedDecision(final, SystemClock.uptimeMillis() - started)
    }

    private suspend fun maybeApplyMembershipAction(
        decision: InviteScanDecision,
        speed: ScanSpeedProfile,
        packageName: String
    ): InviteScanDecision {
        if (shizukuMode) return maybeApplyMembershipActionShizuku(decision, speed, packageName)
        val mode = _state.value.actionMode
        if (mode == ScanActionMode.SCAN_ONLY) return decision
        if (decision.status == ScanStatus.ALREADY_MEMBER || decision.status == ScanStatus.JOINED || decision.status == ScanStatus.REQUEST_PENDING) {
            return decision
        }

        val approval = decision.status == ScanStatus.APPROVAL
        val direct = decision.status == ScanStatus.DIRECT
        if (!approval && !direct) return decision

        if (approval && !_state.value.requestToJoinEnabled) {
            return decision.copy(
                detail = "${decision.detail} — إرسال طلب الانضمام معطل من الإعدادات",
                signalCode = "APPROVAL_ACTION_DISABLED"
            )
        }

        val svc = service ?: return decision.copy(
            status = ScanStatus.ERROR,
            detail = "تعذر تنفيذ الإجراء: Accessibility غير متصلة",
            signalCode = "ACTION_NO_SERVICE",
            definitive = true
        )
        val root = svc.currentRoot()
        _state.value = _state.value.copy(
            status = ScanEngineStatus.CLASSIFYING,
            message = if (approval) "طلب الانضمام • تنفيذ ثم متابعة نفس الرابط" else "الانضمام • تنفيذ ثم متابعة نفس الرابط"
        )
        if (!adapter.inviteActionAvailable(root, approval) || !adapter.clickInviteAction(root, approval)) {
            return decision.copy(
                status = ScanStatus.ACTION_UNCERTAIN,
                detail = "لم يتم العثور على زر الإجراء أو تعذر ضغطه عبر Accessibility",
                signalCode = "ACTION_SEMANTIC_CLICK_FAILED",
                definitive = true
            )
        }
        delay(POST_ACTION_GRACE_MS)

        val deadline = SystemClock.uptimeMillis() + when (speed) {
            ScanSpeedProfile.HYPER -> 3_500L
            ScanSpeedProfile.ADAPTIVE -> 5_000L
            ScanSpeedProfile.SAFE -> 7_000L
        }
        var bestPost = decision
        var positiveFollowUps = 0
        while (SystemClock.uptimeMillis() < deadline) {
            waitIfPaused()
            val current = svc.currentRoot()
            if (current != null && adapter.isWhatsAppRoot(current, packageName)) {
                if (positiveFollowUps < MAX_POSITIVE_FOLLOW_UPS &&
                    adapter.inviteConfirmationAvailable(current) &&
                    adapter.clickInviteConfirmation(current)
                ) {
                    positiveFollowUps++
                    _state.value = _state.value.copy(message = "Continue/Confirm على نفس الرابط • $positiveFollowUps/$MAX_POSITIVE_FOLLOW_UPS")
                    delay(POST_ACTION_GRACE_MS)
                    continue
                }
                val post = InviteScanClassifier.classify(adapter.snapshot(current).texts)
                bestPost = chooseBetter(bestPost, post)
                if (!approval) {
                    val chatVisible = decision.groupName?.let { adapter.isConversationOpenForTarget(current, it, packageName) } == true
                    if (post.status == ScanStatus.ALREADY_MEMBER || chatVisible) {
                        return decision.copy(
                            status = ScanStatus.JOINED,
                            detail = "تم الانضمام والتحقق من انتقال واتساب إلى القروب",
                            signalCode = "JOIN_VERIFIED",
                            confidence = 100,
                            definitive = true
                        )
                    }
                } else if (post.status == ScanStatus.REQUEST_PENDING) {
                    return post.copy(
                        detail = "تم إرسال طلب الانضمام والتحقق من أنه قيد المراجعة",
                        signalCode = "REQUEST_VERIFIED",
                        confidence = 100,
                        definitive = true,
                        groupName = post.groupName ?: decision.groupName,
                        memberCountText = post.memberCountText ?: decision.memberCountText,
                        inviteKind = if (post.inviteKind == InviteKind.UNKNOWN) decision.inviteKind else post.inviteKind
                    )
                }
                if (post.status in setOf(ScanStatus.INVALID, ScanStatus.FULL, ScanStatus.REMOVED, ScanStatus.ACCOUNT_LIMIT)) {
                    return post
                }
            }
            withTimeoutOrNull(speed.eventWaitMs) { uiEvents.first() }
            delay(speed.settleDelayMs)
        }

        return decision.copy(
            status = ScanStatus.ACTION_UNCERTAIN,
            detail = if (approval)
                "تم ضغط طلب الانضمام لكن لم تظهر إشارة تحقق نهائية؛ لن يعاد الضغط تلقائيًا"
            else
                "تم ضغط الانضمام لكن لم تظهر إشارة تحقق نهائية؛ لن يعاد الضغط تلقائيًا",
            signalCode = if (approval) "REQUEST_ACTION_UNCERTAIN" else "JOIN_ACTION_UNCERTAIN",
            confidence = maxOf(decision.confidence, bestPost.confidence),
            definitive = true
        )
    }


    private suspend fun awaitShizukuTree(packageName: String, timeoutMs: Long = 3_000L): ShizukuUiTree? {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        while (SystemClock.elapsedRealtime() < deadline) {
            val tree = shizukuUi.snapshot(packageName)
            if (tree.state == "OK" && tree.nodes.isNotEmpty() && shizukuUi.isWhatsApp(tree, packageName)) return tree
            delay(45L)
        }
        return null
    }

    private suspend fun scanOneShizuku(item: ScanRecord, speed: ScanSpeedProfile): TimedDecision {
        val started = SystemClock.uptimeMillis()
        val packageName = ExtractionController.state.value.selectedWhatsAppPackage
            ?: return TimedDecision(InviteScanDecision(ScanStatus.ERROR, "لم يتم تحديد نسخة واتساب", true, 100, "NO_TARGET_PACKAGE"), 0L)
        awaitNetworkAvailability()
        val preOpenTree = shizukuUi.snapshot(packageName)
        val preOpenSignature = ScanScreenFreshnessGate.signature(preOpenTree.texts)
        if (!openInvite(item.normalizedUrl, packageName)) {
            return TimedDecision(InviteScanDecision(ScanStatus.ERROR, "تعذر فتح الرابط في ${WhatsAppInstanceRegistry.labelFor(packageName)}", true, 100, "LAUNCH_FAILED"), SystemClock.uptimeMillis()-started)
        }
        _state.value = _state.value.copy(status = ScanEngineStatus.CLASSIFYING, message = "Shizuku: تحليل شاشة الدعوة")
        var deadline = SystemClock.uptimeMillis() + speed.previewTimeoutMs
        var last = InviteScanDecision(ScanStatus.UNKNOWN, "بانتظار ظهور حالة الدعوة", false, 0, "WAITING")
        var snapshotIndex = 0
        var sequence = shizukuUi.eventSequence(packageName)

        while(SystemClock.uptimeMillis()<deadline){
            waitIfPaused()
            if(!isNetworkAvailable()){
                _state.value=_state.value.copy(status=ScanEngineStatus.WAITING_NETWORK,message="انقطع الاتصال — انتظار الشبكة بدون تصنيف الرابط كتالف")
                awaitNetworkAvailability(); safelyReturnFromInvite(speed)
                if(!openInvite(item.normalizedUrl,packageName)) return TimedDecision(InviteScanDecision(ScanStatus.ERROR,"عاد الاتصال لكن تعذر فتح نفس الرابط",true,100,"REOPEN_FAILED"),SystemClock.uptimeMillis()-started)
                snapshotIndex=0;deadline=SystemClock.uptimeMillis()+speed.previewTimeoutMs
            }
            val frame=shizukuUi.waitFrame(packageName,sequence,speed.eventWaitMs.toInt().coerceAtLeast(40));sequence=frame.first
            val tree=frame.second.takeIf{it.state=="OK"}?:awaitShizukuTree(packageName,500L)
            if (tree == null) {
                if (recoverRuntimeForCurrentItem(item, "SHIZUKU_UI_LOST")) {
                    deadline = SystemClock.uptimeMillis() + speed.previewTimeoutMs
                    continue
                }
                return TimedDecision(
                    InviteScanDecision(
                        ScanStatus.UNKNOWN,
                        "تعذر استعادة Shizuku/المحرك البديل لنفس الرابط",
                        false,
                        0,
                        "RUNTIME_RECOVERY_FAILED"
                    ),
                    SystemClock.uptimeMillis()-started
                )
            }
            if(tree!=null){
                val candidateSignature = ScanScreenFreshnessGate.signature(tree.texts)
                if (!ScanScreenFreshnessGate.isFresh(preOpenSignature, candidateSignature, false)) {
                    delay(ScanHotLoopPolicy.stalePollDelayMs)
                    continue
                }
                snapshotIndex += 1
                val decision=InviteScanClassifier.classify(tree.texts);last=chooseBetter(last,decision);_state.value=_state.value.copy(currentConfidence=last.confidence)
                when (FastContinuousScanPolicy.next(last, snapshotIndex)) {
                    FastScanAction.SAVE_AND_NEXT -> return TimedDecision(last,SystemClock.uptimeMillis()-started)
                    FastScanAction.SHORT_VERIFY -> delay(FastContinuousScanPolicy.shortVerifyDelayMs)
                    FastScanAction.SAVE_UNKNOWN_AND_NEXT -> return TimedDecision(
                        last.copy(
                            status = ScanStatus.UNKNOWN,
                            detail = "Shizuku: لم تظهر إشارة مؤكدة بعد قراءتين سريعتين",
                            definitive = false,
                            signalCode = "FAST_UNKNOWN"
                        ),
                        SystemClock.uptimeMillis()-started
                    )
                }
            }
            delay(speed.settleDelayMs)
        }
        val final=last.copy(status=last.status,detail=if(last.status==ScanStatus.UNKNOWN)"Shizuku: لم تظهر علامة مؤكدة بعد انتظار شاشة مستقرة" else last.detail,definitive=true,signalCode=if(last.signalCode=="WAITING")"TIMEOUT_NO_SIGNAL" else last.signalCode)
        return TimedDecision(final,SystemClock.uptimeMillis()-started)
    }

    private suspend fun maybeApplyMembershipActionShizuku(decision: InviteScanDecision, speed: ScanSpeedProfile, packageName: String): InviteScanDecision {
        val mode=_state.value.actionMode
        if(mode==ScanActionMode.SCAN_ONLY)return decision
        if(decision.status in setOf(ScanStatus.ALREADY_MEMBER,ScanStatus.JOINED,ScanStatus.REQUEST_PENDING))return decision
        val approval=decision.status==ScanStatus.APPROVAL;val direct=decision.status==ScanStatus.DIRECT
        if(!approval&&!direct)return decision
        if(approval&&!_state.value.requestToJoinEnabled)return decision.copy(detail="${decision.detail} — إرسال طلب الانضمام معطل",signalCode="APPROVAL_ACTION_DISABLED")
        var tree=awaitShizukuTree(packageName,900L)
        _state.value=_state.value.copy(message=if(approval)"Shizuku: طلب انضمام • UI ثم shell fallback" else "Shizuku: انضمام • UI ثم shell fallback")
        val firstAction = when {
            tree != null && shizukuUi.inviteActionAvailable(tree,approval) &&
                shizukuUi.clickInviteAction(tree,packageName,approval) -> true
            else -> shizukuUi.shellClickInviteAction(packageName,approval)
        }
        if(!firstAction)return decision.copy(
            status=ScanStatus.ACTION_UNCERTAIN,
            detail="لم ينجح UIAutomation أو shell semantic fallback",
            signalCode="SHIZUKU_ACTION_ALL_LANES_FAILED",
            definitive=true
        )
        delay(POST_ACTION_GRACE_MS)
        val deadline=SystemClock.uptimeMillis()+when(speed){ScanSpeedProfile.HYPER->3500L;ScanSpeedProfile.ADAPTIVE->5000L;ScanSpeedProfile.SAFE->7000L}
        var best=decision
        var positiveFollowUps=0
        while(SystemClock.uptimeMillis()<deadline){
            val fresh=awaitShizukuTree(packageName,600L)
            if(fresh!=null)tree=fresh
            val currentTree=tree
            if(currentTree==null){
                if(positiveFollowUps<1 && shizukuUi.shellClickInviteConfirmation(packageName)){
                    positiveFollowUps++
                    delay(POST_ACTION_GRACE_MS)
                    continue
                }
                delay(speed.settleDelayMs)
                continue
            }
            if(positiveFollowUps<MAX_POSITIVE_FOLLOW_UPS &&
                shizukuUi.inviteConfirmationAvailable(currentTree) &&
                shizukuUi.clickInviteConfirmation(currentTree,packageName)
            ){
                positiveFollowUps++
                _state.value=_state.value.copy(message="Shizuku: Continue/Confirm على نفس الرابط • $positiveFollowUps/$MAX_POSITIVE_FOLLOW_UPS")
                delay(POST_ACTION_GRACE_MS)
                continue
            }
            val post=InviteScanClassifier.classify(currentTree.texts);best=chooseBetter(best,post)
            if(!approval){val chat=decision.groupName?.let{shizukuUi.isConversationOpenForTarget(currentTree,it,packageName)}==true;if(post.status==ScanStatus.ALREADY_MEMBER||chat)return decision.copy(status=ScanStatus.JOINED,detail="تم الانضمام والتحقق عبر Shizuku",signalCode="JOIN_VERIFIED",confidence=100,definitive=true)}
            else if(post.status==ScanStatus.REQUEST_PENDING)return post.copy(detail="تم إرسال الطلب والتحقق عبر Shizuku",signalCode="REQUEST_VERIFIED",confidence=100,definitive=true,groupName=post.groupName?:decision.groupName,memberCountText=post.memberCountText?:decision.memberCountText,visibleMemberIndicator=post.visibleMemberIndicator?:decision.visibleMemberIndicator,inviteKind=if(post.inviteKind==InviteKind.UNKNOWN)decision.inviteKind else post.inviteKind)
            if(post.status in setOf(ScanStatus.INVALID,ScanStatus.FULL,ScanStatus.REMOVED,ScanStatus.ACCOUNT_LIMIT))return post
            delay(speed.settleDelayMs)
        }
        return decision.copy(status=ScanStatus.ACTION_UNCERTAIN,detail=if(approval)"تم ضغط الطلب لكن لم يظهر إثبات نهائي؛ لن يعاد تلقائيًا" else "تم ضغط الانضمام لكن لم يظهر إثبات نهائي؛ لن يعاد تلقائيًا",signalCode=if(approval)"REQUEST_ACTION_UNCERTAIN" else "JOIN_ACTION_UNCERTAIN",confidence=maxOf(decision.confidence,best.confidence),definitive=true)
    }

    private fun currentAccessibilitySignature(packageName: String): String? {
        val root = recoverLiveService()?.currentRoot() ?: return null
        if (!adapter.isWhatsAppRoot(root, packageName)) return null
        return ScanScreenFreshnessGate.signature(adapter.snapshot(root).texts)
    }

    private suspend fun recoverRuntimeForCurrentItem(item: ScanRecord, reason: String): Boolean {
        if (recoveryInProgress) return false
        recoveryInProgress = true
        try {
            val packageName = ExtractionController.state.value.selectedWhatsAppPackage ?: return false
            val preference = UnifiedRuntimeRepository.preference(appContext)
            val sh = runCatching { ShizukuBridge.status() }.getOrNull()
            val shizukuReady = sh?.let {
                it.binderAlive && it.permissionGranted && it.userServiceBound
            } == true
            val accessibilityReady = recoverLiveService() != null
            val plan = ScanRuntimeRecoveryPolicy.plan(
                preference = preference,
                failedBackend = effectiveScanBackend,
                accessibilityCanRecover = accessibilityReady,
                shizukuReady = shizukuReady
            )

            _state.value = _state.value.copy(
                status = ScanEngineStatus.RECOVERING,
                currentUrl = item.normalizedUrl,
                message = "استعادة المحرك • نفس الرابط • $reason"
            )

            for (step in plan.steps) {
                when (step) {
                    ScanRecoveryStep.RETRY_ACCESSIBILITY,
                    ScanRecoveryStep.SWITCH_TO_ACCESSIBILITY -> {
                        val live = recoverLiveService()
                        if (live != null && adapter.isWhatsAppRoot(live.currentRoot(), packageName)) {
                            shizukuMode = false
                            effectiveScanBackend = RuntimeBackendKind.ACCESSIBILITY
                            return openInvite(item.normalizedUrl, packageName)
                        }
                    }

                    ScanRecoveryStep.RETRY_SHIZUKU,
                    ScanRecoveryStep.SWITCH_TO_SHIZUKU -> {
                        if (ShizukuBridge.ensureBound(appContext, 1_500L)) {
                            shizukuMode = true
                            effectiveScanBackend = RuntimeBackendKind.SHIZUKU
                            return openInvite(item.normalizedUrl, packageName)
                        }
                    }
                }
            }
            return false
        } finally {
            recoveryInProgress = false
        }
    }

    private fun maybeNotifyProgress(force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (force || ScanHotLoopPolicy.shouldNotify(lastProgressNotificationMs, now)) {
            lastProgressNotificationMs = now
            notifier.show(_state.value)
        }
    }

    private fun chooseBetter(a: InviteScanDecision, b: InviteScanDecision): InviteScanDecision {
        if (b.definitive && !a.definitive) return b
        if (a.definitive && !b.definitive) return a
        return if (b.confidence >= a.confidence) b else a
    }

    private suspend fun openInvite(url: String, packageName: String): Boolean {
        val runtimeTarget = UnifiedRuntimeRepository.resolve(appContext, packageName)
        if (runtimeTarget.remoteTarget) {
            if (runtimeTarget.effectiveBackend != com.althmany.extractor.profile.RuntimeBackendKind.SHIZUKU) {
                return false
            }
            return ShizukuBridge.launchUrl(
                appContext,
                packageName,
                url,
                runtimeTarget.targetAndroidUserId
            )
        }

        return runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                setPackage(packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            }
            appContext.startActivity(intent)
            true
        }.getOrDefault(false)
    }

    private suspend fun safelyReturnFromInvite(speed: ScanSpeedProfile) {
        val packageName = ExtractionController.state.value.selectedWhatsAppPackage ?: return
        val runtimeTarget = UnifiedRuntimeRepository.resolve(appContext, packageName)
        if (shizukuMode) {
            val tree = awaitShizukuTree(packageName, 180L)
            if (tree != null && shizukuUi.clickInviteClose(tree, packageName)) {
                delay(maxOf(speed.settleDelayMs, 18L))
                return
            }
            ShizukuBridge.fastBack(appContext)
            delay(maxOf(speed.settleDelayMs, 18L))
            val after = awaitShizukuTree(packageName, 180L)
            if (after == null || !shizukuUi.isWhatsApp(after, packageName)) {
                ShizukuBridge.launchPackage(appContext, packageName, runtimeTarget.targetAndroidUserId)
            }
            return
        }
        val svc = service ?: recoverLiveService() ?: return
        val root = svc.currentRoot()
        if (root != null && adapter.isWhatsAppRoot(root, packageName) && adapter.clickInviteClose(root)) {
            withTimeoutOrNull(speed.eventWaitMs) { uiEvents.first() }
            delay(maxOf(speed.settleDelayMs, 18L))
            return
        }
        svc.performBack()
        withTimeoutOrNull(speed.eventWaitMs) { uiEvents.first() }
        delay(maxOf(speed.settleDelayMs, 18L))
        val after = svc.currentRoot()
        if (after == null || !adapter.isWhatsAppRoot(after, packageName)) {
            ExtractionController.openWhatsApp()
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private suspend fun awaitNetworkAvailability() {
        while (!isNetworkAvailable()) {
            waitIfPaused()
            _state.value = _state.value.copy(
                status = ScanEngineStatus.WAITING_NETWORK,
                running = true,
                message = "لا يوجد اتصال إنترنت — لن يتم تصنيف الرابط كتالف، بانتظار الشبكة"
            )
            notifier.show(_state.value)
            delay(650L)
        }
    }

    private suspend fun waitIfPaused() {
        while (pauseRequested) delay(120)
    }
}
