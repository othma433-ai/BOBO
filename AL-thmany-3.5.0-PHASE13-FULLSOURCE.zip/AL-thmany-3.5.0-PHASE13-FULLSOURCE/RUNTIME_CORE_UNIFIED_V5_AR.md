# AL-thmany 3.4.1 — Runtime Core Unified v5

## الإصلاحات الحاكمة

1. **Accessibility Runtime واحد فعليًا**
   - الخدمة الوحيدة المسجلة في `AndroidManifest.xml` هي `QuickJoinAccessibilityService`.
   - نفس الخدمة تربط `ExtractionController` و`ScanController` و`PublishController`.
   - أزيل تسجيل `WhatsAppAccessibilityService` الثاني لمنع سباق الـactive driver والـroot.

2. **Extraction Single‑Flight**
   - محاولة واحدة للقروب في الدورة الحالية.
   - لا يوجد إعداد يدوي لعدد retries في الواجهة.
   - عند الفشل يصبح القروب `FAILED` ويبقى ضمن قائمة القروبات غير المكتملة ليعاد جدولته في تشغيل لاحق، بدل التكرار الفوري أو `FAILED_FINAL`.

3. **Scan Read‑Only**
   - واجهة Scan لا تعرض Join / Request to Join / Scan+Join.
   - `ScanController` يجبر التشغيل على `SCAN_ONLY` ويعطل Request to Join.
   - محرك Join المستقل يبقى المسؤول الوحيد عن أفعال العضوية.

4. **Unified Runtime Settings**
   - Backend والهدف مشتركان أصلًا عبر `UnifiedRuntimeTargetStore`.
   - سرعة التشغيل العامة أصبحت مشتركة بين Extraction / Scan / Publish عبر `UnifiedRuntimeSettingsStore`.
   - الخيارات الوظيفية الخاصة بكل خاصية تبقى في Store الخاص بها (مثل Scope للفحص أو محتوى النشر).

## التحقق

- `validate_runtime_core_unified_v5.py`: PASS
- `validate_integrated_extractor.py`: PASS
- `validate_smart_extraction_ui.py`: PASS
- `validate_unified_runtime_v341.py`: PASS
- `validate_runtime_unified_v3.py`: PASS بعد تحديثه لمعمارية Accessibility الموحدة
- `validate_source.py`: PASS
- `run_pure_kotlin_regressions.sh`: PASS

## ملاحظة البناء

لا يوجد Gradle Wrapper تنفيذي داخل المصدر الحالي ولا Gradle مثبت في بيئة التنفيذ، لذلك التحقق هنا Source-level + pure Kotlin regression وليس APK build على Android.
