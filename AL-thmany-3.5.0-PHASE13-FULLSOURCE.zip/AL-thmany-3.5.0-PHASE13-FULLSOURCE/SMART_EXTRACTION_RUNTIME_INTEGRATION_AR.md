# Smart Extraction + Runtime Unified Integration v4

هذه الحزمة هي تحديث الاستخراج الموحد داخل نفس مشروع AL-thmany 3.4.1.

## ما الذي تم دمجه؟

- جميع مكونات Smart Extraction UI Final محفوظة بالكامل.
- Group Registry وSmart Extraction Coordinator وContinuous Adaptive Scrolling وFast End Verification وCheckpoint/Resume محفوظة.
- All Groups يعمل من أسفل إلى أعلى (الأحدث إلى الأقدم).
- Unread Groups يعمل من أعلى الرسائل الجديدة إلى أسفل (الأقدم غير المقروء إلى الأحدث).
- إصلاحات Runtime Unified v3 أُدرجت داخل نفس المشروع، وليست Patch منفصلًا.
- Join / Scan / Publish تستخدم سياسة Runtime موحدة وSingle-Flight لكل مهمة.
- Accessibility runtime موحد عبر AccessibilityUiDriver مع دعم التوافق للخدمات القديمة.
- Shizuku يبقى Backend مستقلًا للبيئات التي لا يغطيها Accessibility بصورة موثوقة.
- اكتشاف WhatsApp أصبح ديناميكيًا، مع دعم Samsung Dual Messenger بما في ذلك user 95 عندما يكون متاحًا.
- واجهات النتائج الطويلة تعرض أول أربعة أسطر ثم عرض المزيد/أقل.
- واجهة عربية RTL ومحاذاة نصوص عربية من اليمين لليسار.

## العلاقة مع الحزم السابقة

هذه الحزمة تستبدل الحاجة إلى استخدام حزمتين منفصلتين:

1. AL-thmany-3.4.1-Smart-Extraction-UI-Final
2. AL-thmany-3.4.1-Runtime-Unified-v3

Runtime Unified v3 ثبت أنه Superset لتحديث Smart Extraction: لا يوجد ملف من Smart Extraction مفقود، مع إضافات وتعديلات Runtime فوقه.
