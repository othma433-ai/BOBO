# Smart Extraction Integrated Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Integrate the agreed Smart Extraction workflow into the existing AL-thmany 3.4.1 Extraction feature.

**Architecture:** Extend the existing ExtractionController/Settings/UI rather than creating a parallel app. Add a pure SmartExtractionPolicy for locked direction/preset/end-budget rules; reuse existing database and runtime backends; make Search the preferred automated group handoff route.

**Tech Stack:** Kotlin 2.x, Android AccessibilityService, Shizuku, Jetpack Compose, SharedPreferences, existing SQLite repository.

**Spec:** `docs/superpowers/specs/2026-09-17-smart-extraction-integrated-design.md`

## Global Constraints
- Existing app only; no new Android application/module.
- ALL/Deep direction = toward older messages.
- UNREAD direction = oldest unread/checkpoint toward newest messages.
- Normal end decision budget < 1000 ms.
- Group sync capacity >= 10,000.
- Existing Settings remain source of truth.

### Task 1: Smart extraction policy
Create pure direction/preset/end-budget policy and regression checks.

### Task 2: Settings + UI state
Persist continuous scroll, fast end verification, hidden search navigation and fast-end budget in existing extraction settings; expose in UI state.

### Task 3: Navigation
Prefer automated exact-name Search from the registry, then verify target identity; retain visible/scroll routes as recovery.

### Task 4: Extraction directions
Keep ALL/Deep older-direction behavior; rebuild NEW_ONLY as seek-boundary then continuous newer-direction extraction.

### Task 5: Scale sync
Raise sync capacity for 10k+ groups and keep event-first termination.

### Task 6: Extraction UI
Enhance the existing V341 extraction screen with locked workflow cards, mode-linked presets, counts, performance and reliability toggles.

### Task 7: Verification/package
Run pure regressions, smart extraction checks, source validators, and package the modified source project.
