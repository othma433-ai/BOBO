# Smart Extraction Integrated Design

## Goal
Rebuild the existing Extraction feature inside AL-thmany 3.4.1 without creating a second app. Keep the current UI language/design system, Settings, Accessibility/Shizuku backends, database, notifications, and runtime ownership, while replacing the extraction behavior with the agreed high-scale workflow.

## Locked behavior
- Group sync builds/refreshes the existing group registry and must support at least 10,000 groups.
- ALL/Deep selection: start at newest messages and move continuously toward older messages (bottom -> top).
- UNREAD selection: identify oldest unread/checkpoint boundary, then extract continuously toward newest messages (top -> bottom).
- Link capture happens during scrolling and is persisted immediately.
- End verification is multi-signal, event-first, and targets < 1 second in the normal path.
- Group handoff is registry-driven and automatically uses exact-name Search as the preferred hidden navigation route, with identity verification after open.
- Existing application Settings remain the source of truth. No duplicate configuration store.
- Pause/resume/stop/retry/checkpoint remain available.

## UI
Keep the current V341 extraction screen and visual language. Add a smart workflow card showing direction, continuous scrolling, fast-end verification, hidden search navigation, selected/total/unread counts, and current group progress. Preset ALL binds mode to ALL_CHATS; preset UNREAD binds mode to NEW_ONLY.

## Safety and reliability
Never mark a group complete solely because one gesture failed. Failed/ambiguous opens remain retryable. Search navigation must verify the opened chat title/target before extraction.
