package checks

import com.althmany.extractor.data.ExtractionMode
import com.althmany.extractor.data.GroupSelectionPreset
import com.althmany.extractor.engine.ExtractionPolicy
import com.althmany.extractor.engine.SmartExtractionDirection
import com.althmany.extractor.engine.SmartExtractionPolicy

private fun checkThat(value: Boolean, message: String) {
    if (!value) error(message)
}

fun main() {
    checkThat(SmartExtractionPolicy.directionFor(ExtractionMode.ALL_CHATS) == SmartExtractionDirection.TOWARD_OLDER,
        "ALL_CHATS must move from newest toward oldest")
    checkThat(SmartExtractionPolicy.directionFor(ExtractionMode.DEEP) == SmartExtractionDirection.TOWARD_OLDER,
        "DEEP must move from newest toward oldest")
    checkThat(SmartExtractionPolicy.directionFor(ExtractionMode.NEW_ONLY) == SmartExtractionDirection.TOWARD_NEWER,
        "NEW_ONLY must move from oldest unread toward newest")
    checkThat(SmartExtractionPolicy.modeForPreset(GroupSelectionPreset.ALL) == ExtractionMode.ALL_CHATS,
        "Select all must bind to ALL_CHATS")
    checkThat(SmartExtractionPolicy.modeForPreset(GroupSelectionPreset.UNREAD) == ExtractionMode.NEW_ONLY,
        "Unread preset must bind to NEW_ONLY")
    checkThat(SmartExtractionPolicy.fastEndDecisionBudgetMs(260, 140) < 1000,
        "fast end verification must stay below one second")
    checkThat(ExtractionPolicy.MAX_SYNC_ITEMS >= 10_000,
        "sync capacity must support the user's ~10k groups")
    println("SMART EXTRACTION V2 CHECKS: PASS")
}
