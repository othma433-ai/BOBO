from pathlib import Path
root=Path('.')
checks=[]
def has(path,*needles):
    text=(root/path).read_text(encoding='utf-8')
    return all(n in text for n in needles)
def check(name, ok):
    checks.append((name,ok)); print(('PASS' if ok else 'FAIL')+': '+name)
check('single-flight runtime policy', has(Path('app/src/main/java/com/althmany/groupmanager/domain/RuntimeUnifiedPolicy.kt'),'actionAttempts = 1','scanAttempts = 1','publishAttempts = 1'))
check('join does not pause on controlled exit', has(Path('app/src/main/java/com/althmany/extractor/join/OriginalJoinCoordinator.kt'),'RuntimeUnifiedPolicy.pauseOnControlledExit','RuntimeUnifiedPolicy.autoResumeAfterControlledExit'))
check('accessibility join service is unified driver', has(Path('app/src/main/java/com/althmany/groupmanager/accessibility/QuickJoinAccessibilityService.kt'),'AccessibilityUiDriver','attachUnifiedExtractorControllers','routeUnifiedExtractorEvent'))
manifest=(root/Path('app/src/main/AndroidManifest.xml')).read_text(encoding='utf-8')
check('single registered accessibility runtime', manifest.count('android.permission.BIND_ACCESSIBILITY_SERVICE') == 1 and 'QuickJoinAccessibilityService' in manifest and 'WhatsAppAccessibilityService' not in manifest)
check('scan uses common accessibility driver', has(Path('app/src/main/java/com/althmany/extractor/engine/ScanController.kt'),'AccessibilityUiDriver'))
check('publish uses common accessibility driver', has(Path('app/src/main/java/com/althmany/extractor/engine/PublishController.kt'),'AccessibilityUiDriver'))
check('extraction uses common accessibility driver', has(Path('app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt'),'AccessibilityUiDriver'))
check('scan max attempts fixed to one', has(Path('app/src/main/java/com/althmany/extractor/engine/ScanSettingsStore.kt'),'fun loadMaxAttempts(): Int = 1'))
check('publish max attempts fixed to one', has(Path('app/src/main/java/com/althmany/extractor/engine/PublishSettingsStore.kt'),'fun maxAttempts(): Int = 1'))
check('dual messenger user 95 forced discovery', has(Path('app/src/main/java/com/althmany/extractor/profile/UnifiedRuntimeTarget.kt'),'95 to "Dual Messenger"'))
check('dynamic installed app discovery lane', has(Path('app/src/main/java/com/althmany/extractor/profile/WhatsAppInstanceRegistry.kt'),'getInstalledApplications(0)','looksLikeWhatsApp'))
check('scan results four-line expansion', has(Path('app/src/main/java/com/althmany/extractor/ui/Screens.kt'),'ExpandableFourLineText','عرض المزيد','maxLines = if (expanded) Int.MAX_VALUE else 4'))
check('stale terminal handoff recovery', has(Path('app/src/main/java/com/althmany/groupmanager/accessibility/QuickJoinAccessibilityService.kt'),'STALE_TERMINAL_HANDOFF','scanPending.set(true)'))
if not all(v for _,v in checks): raise SystemExit(1)
print('\nRUNTIME UNIFIED V3 SOURCE CHECKS: PASS')
