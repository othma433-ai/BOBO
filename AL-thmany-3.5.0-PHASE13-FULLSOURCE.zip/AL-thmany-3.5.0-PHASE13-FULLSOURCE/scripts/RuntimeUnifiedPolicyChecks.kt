package com.althmany.runtimechecks

import com.althmany.groupmanager.domain.RuntimeUnifiedPolicy

fun main() {
    check(RuntimeUnifiedPolicy.actionAttempts == 1) { "actionAttempts must be single-flight" }
    check(RuntimeUnifiedPolicy.scanAttempts == 1) { "scanAttempts must be single-flight" }
    check(RuntimeUnifiedPolicy.autoAdvance) { "autoAdvance must be enabled" }
    check(!RuntimeUnifiedPolicy.pauseOnControlledExit) { "controlled X/Back must not pause" }
    check(RuntimeUnifiedPolicy.autoResumeAfterControlledExit) { "controlled exit must auto-resume" }
    check(RuntimeUnifiedPolicy.terminalHandoffMs in 0L..250L) { "terminal handoff must remain fast" }
    println("RuntimeUnifiedPolicyChecks: PASS")
}
