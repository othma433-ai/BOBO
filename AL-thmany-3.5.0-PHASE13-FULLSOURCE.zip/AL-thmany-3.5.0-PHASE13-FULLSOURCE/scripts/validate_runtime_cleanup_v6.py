from pathlib import Path
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/althmany/extractor'
checks=[]

def text(p): return (root/p).read_text(encoding='utf-8')

allkt='\n'.join(p.read_text(encoding='utf-8', errors='ignore') for p in src.rglob('*.kt'))
checks.append(('no extraction retry API', 'setExtractionRetries' not in allkt and 'setMaxSameGroupRetries' not in allkt and 'same_group_retries' not in allkt))
checks.append(('no legacy V341 scan screen', 'fun V341ScanScreen(' not in allkt and 'import com.althmany.extractor.ui.V341ScanScreen' not in allkt))
repo=src/'profile/UnifiedRuntimeRepository.kt'
checks.append(('unified runtime repository exists', repo.exists()))
if repo.exists():
    rt=repo.read_text(encoding='utf-8')
    checks.append(('repository owns target/backend/speed facade', all(k in rt for k in ['fun resolve(', 'fun preference(', 'fun speed(', 'fun setSpeed(', 'fun setLocalTarget('])))
# active high-level runtime consumers must not directly import the two underlying stores
for rel in ['ExtractorApp.kt','engine/ExtractionController.kt','engine/ScanController.kt','engine/PublishController.kt','ui/AppViewModel.kt','join/OriginalJoinCoordinator.kt']:
    p=src/rel
    t=p.read_text(encoding='utf-8')
    checks.append((f'{rel} uses repository facade', 'UnifiedRuntimeTargetStore' not in t and 'UnifiedRuntimeSettingsStore' not in t))

failed=[name for name,ok in checks if not ok]
for name,ok in checks:
    print(('PASS' if ok else 'FAIL'), name)
if failed:
    raise SystemExit(1)
print('RUNTIME CLEANUP V6: PASS')
