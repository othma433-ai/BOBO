from pathlib import Path
root=Path(__file__).resolve().parents[1]
ui=(root/'app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt').read_text()
main=(root/'app/src/main/java/com/althmany/extractor/MainActivity.kt').read_text()
checks={
 'workflow card':'محرك الاستخراج الذكي',
 'continuous scroll toggle':'السحب المستمر',
 'fast end toggle':'التحقق السريع من النهاية',
 'hidden nav toggle':'الانتقال المخفي',
 'checkpoint toggle':'حفظ نقطة الاستكمال',
 'all direction':'أسفل ← أعلى',
 'unread direction':'أعلى ← أسفل',
 'progress':'القروب الحالي',
}
missing=[name for name,text in checks.items() if text not in ui]
for callback in ['onContinuousScroll','onFastEndVerification','onHiddenSearchNavigation','onCheckpointEnabled']:
    if callback not in ui or callback not in main:
        missing.append('callback '+callback)
if missing:
    raise SystemExit('MISSING: '+', '.join(missing))
print('SMART EXTRACTION UI CHECKS: PASS')
