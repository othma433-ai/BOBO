from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
manifest = (root/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
quick = (root/'app/src/main/java/com/althmany/groupmanager/accessibility/QuickJoinAccessibilityService.kt').read_text(encoding='utf-8')
extract_ctl = (root/'app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt').read_text(encoding='utf-8')
models = (root/'app/src/main/java/com/althmany/extractor/data/Models.kt').read_text(encoding='utf-8')
ext_settings = (root/'app/src/main/java/com/althmany/extractor/engine/ExtractionSettingsStore.kt').read_text(encoding='utf-8')
scan_settings = (root/'app/src/main/java/com/althmany/extractor/engine/ScanSettingsStore.kt').read_text(encoding='utf-8')
pub_settings = (root/'app/src/main/java/com/althmany/extractor/engine/PublishSettingsStore.kt').read_text(encoding='utf-8')
scan_state = (root/'app/src/main/java/com/althmany/extractor/engine/ScanUiState.kt').read_text(encoding='utf-8')
workspace_all = (root/'app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt').read_text(encoding='utf-8')
professional = (root/'app/src/main/java/com/althmany/extractor/ui/ProfessionalJoinScanScreens.kt').read_text(encoding='utf-8')
workspace = professional.split('fun ProfessionalScanScreen',1)[1]
smart_all = (root/'app/src/main/java/com/althmany/extractor/ui/SmartWorkspaceScreens.kt').read_text(encoding='utf-8')
smart = smart_all.split('fun WorkspaceScanScreen',1)[1]
dash = (root/'app/src/main/java/com/althmany/extractor/ui/DashboardScreen.kt').read_text(encoding='utf-8')
main = (root/'app/src/main/java/com/althmany/extractor/MainActivity.kt').read_text(encoding='utf-8')

checks = []
def check(name, cond):
    checks.append((name, bool(cond)))

check('single accessibility service registered', 'QuickJoinAccessibilityService' in manifest and 'com.althmany.extractor.accessibility.WhatsAppAccessibilityService' not in manifest)
check('quickjoin routes extractor controllers', all(x in quick for x in ['ExtractionController.attachService(this)', 'ScanController.attachService(this)', 'PublishController.attachService(this)']))
check('extractor accepts only unified accessibility class', 'WhatsAppAccessibilityService' not in extract_ctl and 'QuickJoinAccessibilityService::class.java.name' in extract_ctl)
check('main accessibility detection accepts only unified service', 'com.althmany.extractor.accessibility.WhatsAppAccessibilityService' not in main and 'QuickJoinAccessibilityService' in main)
check('extraction is single flight with no retry API', 'maxSameGroupRetries' not in models and 'setMaxSameGroupRetries' not in ext_settings and 'setMaxSameGroupRetries' not in extract_ctl)
check('failed extraction queued not final', 'ProcessOutcome.FAILED -> repository.updateStatus(group.id, GroupStatus.FAILED,' in extract_ctl)
check('retry UI removed', 'إعادة المحاولة' not in dash and 'المحاولات' not in smart)
check('scan runtime is scan-only', 'fun loadActionMode(): ScanActionMode = ScanActionMode.SCAN_ONLY' in scan_settings and 'setActionMode(ScanActionMode.SCAN_ONLY)' in (root/'app/src/main/java/com/althmany/extractor/engine/ScanController.kt').read_text(encoding='utf-8'))
check('scan join choices removed from active scan UI', 'ScanActionMode.entries' not in workspace and 'فحص + انضمام' not in workspace and 'انضمام مباشر' not in workspace)
check('scan join choices removed from smart workspace', 'ScanActionMode.entries' not in smart and 'بدء الفحص + الانضمام' not in smart)
check('shared runtime repository used by feature stores', all('UnifiedRuntimeRepository' in s for s in [ext_settings, scan_settings, pub_settings]))

bad = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if bad:
    print(f'\n{len(bad)} check(s) failed')
    sys.exit(1)
print('\nRUNTIME CORE UNIFIED V5: PASS')
