#!/usr/bin/env python3
from pathlib import Path
import argparse, shutil, subprocess, sys, time, json

PATCH_VERSION = "3.4.2-corrective-extraction-2"
BASELINE_COMMIT = "760ce4a360b3334e95e80e0b657467fbab2c3fbf"

FILES = {
    "ui": Path("app/src/main/java/com/althmany/extractor/ui/WorkspaceV341Screens.kt"),
    "scan": Path("app/src/main/java/com/althmany/extractor/engine/ScanController.kt"),
    "publish": Path("app/src/main/java/com/althmany/extractor/engine/PublishController.kt"),
    "extract": Path("app/src/main/java/com/althmany/extractor/engine/ExtractionController.kt"),
    "extract_settings": Path("app/src/main/java/com/althmany/extractor/engine/ExtractionSettingsStore.kt"),
}

def die(msg):
    print(f"[ERROR] {msg}", file=sys.stderr)
    sys.exit(2)

def replace_exact(text, old, new, label, min_count=1, max_count=None):
    count = text.count(old)
    if count < min_count:
        die(f"{label}: expected at least {min_count} match(es), found {count}. Baseline may have changed.")
    if max_count is not None and count > max_count:
        die(f"{label}: expected at most {max_count} match(es), found {count}. Refusing unsafe patch.")
    return text.replace(old, new), count

def patch(path, ops):
    text = path.read_text(encoding="utf-8")
    for old, new, label, min_count, max_count in ops:
        text, count = replace_exact(text, old, new, label, min_count, max_count)
        print(f"[PATCH] {label}: {count}")
    path.write_text(text, encoding="utf-8", newline="\n")

def run(cmd, cwd):
    print("[RUN]", " ".join(cmd))
    p = subprocess.run(cmd, cwd=cwd)
    if p.returncode != 0:
        die(f"Command failed ({p.returncode}): {' '.join(cmd)}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".")
    ap.add_argument("--no-build", action="store_true")
    args = ap.parse_args()
    repo = Path(args.repo).resolve()

    if not (repo/"settings.gradle.kts").exists() or not (repo/"app/build.gradle.kts").exists():
        die("Run from BOBO Android project root")

    for rel in FILES.values():
        if not (repo/rel).exists():
            die(f"Missing required file: {rel}")

    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup = repo/f".althmany-backup-{PATCH_VERSION}-{stamp}"
    for rel in FILES.values():
        dst = backup/rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(repo/rel, dst)
    print("[BACKUP]", backup)

    patch(repo/FILES["ui"], [
        ("entries.reversed().forEach { (screen, label, icon) ->",
         "entries.forEach { (screen, label, icon) ->",
         "RTL bottom bar double-reverse", 1, 1),
    ])

    patch(repo/FILES["scan"], [
        ("private suspend fun ensureRuntimeReady(timeoutMs: Long = 8_500L): Boolean",
         "private suspend fun ensureRuntimeReady(timeoutMs: Long = 12_000L): Boolean",
         "Scan readiness budget", 1, 1),
        ("SystemClock.elapsedRealtime() + minOf(timeoutMs, 1_800L)",
         "SystemClock.elapsedRealtime() + minOf(timeoutMs, 5_000L)",
         "Scan Accessibility recovery window", 1, 1),
        ("(timeoutMs - 1_800L).coerceAtLeast(5_000L)",
         "(timeoutMs - 5_000L).coerceAtLeast(6_000L)",
         "Scan Shizuku fallback window", 1, 1),
        ("val root = service?.currentRoot()",
         "val root = recoverLiveService()?.currentRoot()",
         "Scan stale root recovery", 1, None),
    ])

    patch(repo/FILES["publish"], [
        ("private suspend fun ensureRuntimeReady(timeoutMs: Long = 8_500L): Boolean",
         "private suspend fun ensureRuntimeReady(timeoutMs: Long = 12_000L): Boolean",
         "Publish readiness budget", 1, 1),
        ("SystemClock.elapsedRealtime() + minOf(timeoutMs, 1_800L)",
         "SystemClock.elapsedRealtime() + minOf(timeoutMs, 5_000L)",
         "Publish Accessibility recovery window", 1, 1),
        ("(timeoutMs - 1_800L).coerceAtLeast(5_000L)",
         "(timeoutMs - 5_000L).coerceAtLeast(6_000L)",
         "Publish Shizuku fallback window", 1, 1),
        ("val root = service?.currentRoot()",
         "val root = recoverLiveService()?.currentRoot()",
         "Publish stale root recovery", 1, None),
    ])

    ex = repo/FILES["extract"]
    patch(ex, [
        ("val liveAccessibility = awaitRuntimeService(1_500L)",
         "val liveAccessibility = awaitRuntimeService(5_000L)",
         "Extraction Accessibility service wait", 1, 1),
        ("awaitWhatsAppRoot(liveAccessibility, targetPackage, 1_800L)",
         "awaitWhatsAppRoot(liveAccessibility, targetPackage, 5_000L)",
         "Extraction WhatsApp root wait", 1, 1),
        ("service?.currentRoot()",
         "recoverLiveService()?.currentRoot()",
         "Extraction live-root recovery", 3, None),
    ])

    text = ex.read_text(encoding="utf-8")
    call_marker = '''        var totalNew = 0
        var iterations = 0
        var unreadBoundarySeen = false
        var finishReason: String? = null

        _state.value = _state.value.copy(status = EngineStatus.EXTRACTING, message = "قراءة المحادثة والسحب للرسائل الأقدم")
'''
    call_repl = '''        var totalNew = 0
        var iterations = 0
        var unreadBoundarySeen = false
        var finishReason: String? = null

        if (!fastForwardResume) {
            _state.value = _state.value.copy(
                status = EngineStatus.EXTRACTING,
                message = "تثبيت أحدث رسالة قبل المسح العميق…",
                phaseDetail = "deep-seek-newest"
            )
            totalNew += seekNewestBeforeDeep(group, prefs, seen)
        }

        _state.value = _state.value.copy(status = EngineStatus.EXTRACTING, message = "قراءة المحادثة والسحب للرسائل الأقدم")
'''
    text, _ = replace_exact(text, call_marker, call_repl, "Deep starts from newest", 1, 1)

    helper_marker = '''    /**
     * NEW_ONLY workflow locked by the Smart Extraction design:
'''
    helper = '''    /**
     * Normalize a fresh deep/all run to WhatsApp's newest-message boundary.
     * Capture URLs before and after every move so an unread-open position cannot
     * skip links while travelling to the bottom.
     */
    private suspend fun seekNewestBeforeDeep(
        group: TargetGroup,
        prefs: ExtractionPreferences,
        seen: MutableSet<String>
    ): Int {
        val svc = recoverLiveService() ?: error("Accessibility service disconnected")
        val timing = ExtractionPolicy.timing(prefs.speed)
        var totalNew = 0
        var passes = 0
        val maxSeekPasses = minOf(prefs.maxScrollIterations, 240)

        while (stateStore.active && passes < maxSeekPasses) {
            awaitIfPaused()
            ensureWhatsAppForeground(prefs)
            val root = recoverLiveService()?.currentRoot() ?: run {
                awaitUiChange(timing.eventQuietMs)
                continue
            }
            if (!adapter.isConversationOpenForTarget(root, group.name, selectedPackageOrNull())) {
                error("خرج واتساب من المجموعة أثناء تثبيت أحدث رسالة")
            }

            val before = adapter.snapshot(root)
            totalNew += captureVisibleLinks(group, seen)

            val moved = adapter.scrollGenericForward(root) ||
                svc.swipeTowardNewerMessages(timing.gestureDurationMs)
            val burst = captureBurst(group, seen, timing)
            totalNew += burst.newLinks
            passes++

            val changed = burst.snapshot.contentSignature != before.contentSignature
            if (!changed && burst.newLinks == 0) {
                val newestConfirmed = if (prefs.fastEndVerificationEnabled) {
                    proveFastEnd(
                        group, seen, timing,
                        directionForward = true,
                        budgetMs = prefs.fastEndVerificationMs
                    )
                } else {
                    proveQuietEnd(group, seen, timing, directionForward = true)
                }
                if (newestConfirmed) {
                    repository.log(
                        group.name,
                        "INFO",
                        "deep-newest-normalized",
                        "تم تثبيت أحدث رسالة قبل المسح العميق بعد $passes حركة"
                    )
                    return totalNew
                }
            }

            if (!moved && !changed) {
                awaitUiChange(timing.eventQuietMs)
            }
        }

        throw EndUnverifiedException("تعذر تثبيت أحدث رسالة قبل المسح العميق ضمن حد الحماية")
    }

'''
    text, _ = replace_exact(text, helper_marker, helper + helper_marker, "Insert newest-seek helper", 1, 1)
    ex.write_text(text, encoding="utf-8", newline="\n")

    text = ex.read_text(encoding="utf-8")
    shiz_call_marker = '''        val seen = hashSetOf<String>()
        var totalNew = 0
        var iterations = 0
        var quietRounds = 0
        var sequence = shizukuUi.eventSequence(packageName)
        _state.value = _state.value.copy(status = EngineStatus.EXTRACTING, message = "Shizuku Event-first: قراءة وسحب الرسائل الأقدم")
'''
    shiz_call_repl = '''        val seen = hashSetOf<String>()
        var totalNew = 0
        var iterations = 0
        var quietRounds = 0
        var sequence = shizukuUi.eventSequence(packageName)

        _state.value = _state.value.copy(
            status = EngineStatus.EXTRACTING,
            message = "Shizuku: تثبيت أحدث رسالة قبل المسح العميق…",
            phaseDetail = "deep-seek-newest"
        )
        val normalized = seekNewestBeforeDeepViaShizuku(group, prefs, packageName, tree, sequence, seen)
        tree = normalized.tree
        sequence = normalized.sequence
        totalNew += normalized.newLinks

        _state.value = _state.value.copy(status = EngineStatus.EXTRACTING, message = "Shizuku Event-first: قراءة وسحب الرسائل الأقدم")
'''
    text, _ = replace_exact(text, shiz_call_marker, shiz_call_repl, "Shizuku deep starts from newest", 1, 1)

    shiz_helper_marker = '''    private suspend fun extractDeepViaShizuku(group: TargetGroup, prefs: ExtractionPreferences, packageName: String) {
'''
    shiz_helper = '''    private data class ShizukuNewestResult(
        val tree: ShizukuUiTree,
        val sequence: Long,
        val newLinks: Int
    )

    private suspend fun seekNewestBeforeDeepViaShizuku(
        group: TargetGroup,
        prefs: ExtractionPreferences,
        packageName: String,
        initialTree: ShizukuUiTree,
        initialSequence: Long,
        seen: MutableSet<String>
    ): ShizukuNewestResult {
        val timing = ExtractionPolicy.timing(prefs.speed)
        var tree = initialTree
        var sequence = initialSequence
        var totalNew = 0
        var passes = 0
        val maxSeekPasses = minOf(prefs.maxScrollIterations, 240)

        while (stateStore.active && passes < maxSeekPasses) {
            awaitIfPaused()
            if (!shizukuUi.isConversationOpenForTarget(tree, group.name, packageName)) {
                error("Shizuku فقد محادثة القروب أثناء تثبيت أحدث رسالة")
            }

            val before = tree.contentSignature
            totalNew += captureShizukuLinks(group, tree, seen)

            val moved = shizukuUi.swipeListForward(tree, timing.gestureDurationMs.toInt())
            val frame = shizukuUi.waitFrame(
                packageName,
                sequence,
                timing.eventQuietMs.toInt().coerceAtLeast(50)
            )
            sequence = frame.first
            val next = frame.second.takeIf { it.state == "OK" } ?: shizukuUi.snapshot(packageName)
            val newlyFound = captureShizukuLinks(group, next, seen)
            totalNew += newlyFound
            val changed = next.contentSignature != before
            tree = next
            passes++

            if (!changed && newlyFound == 0) {
                val proofBefore = tree.contentSignature
                val probeMoved = shizukuUi.swipeListForward(tree, timing.gestureDurationMs.toInt())
                val proofFrame = shizukuUi.waitFrame(
                    packageName,
                    sequence,
                    prefs.fastEndVerificationMs.toInt().coerceIn(120, 700)
                )
                sequence = proofFrame.first
                val proofTree = proofFrame.second.takeIf { it.state == "OK" } ?: shizukuUi.snapshot(packageName)
                val proofNew = captureShizukuLinks(group, proofTree, seen)
                totalNew += proofNew
                val stable = proofTree.contentSignature == proofBefore && proofNew == 0
                tree = proofTree
                if (stable && (!probeMoved || stable)) {
                    repository.log(
                        group.name,
                        "INFO",
                        "shizuku-deep-newest-normalized",
                        "تم تثبيت أحدث رسالة قبل المسح العميق عبر Shizuku بعد $passes حركة"
                    )
                    return ShizukuNewestResult(tree, sequence, totalNew)
                }
            }

            if (!moved && !changed) delay(timing.eventQuietMs.coerceAtMost(120L))
        }

        throw EndUnverifiedException("Shizuku: تعذر تثبيت أحدث رسالة قبل المسح العميق")
    }

'''
    text, _ = replace_exact(text, shiz_helper_marker, shiz_helper + shiz_helper_marker,
                            "Insert Shizuku newest-seek helper", 1, 1)
    ex.write_text(text, encoding="utf-8", newline="\n")

    patch(repo/FILES["extract_settings"], [
        ('continuousScrollEnabled = prefs.getBoolean("continuous_scroll", true),',
         'continuousScrollEnabled = true,',
         "Lock continuous adaptive scrolling ON", 1, 1),
        ('prefs.edit().putBoolean("continuous_scroll", enabled).apply()',
         'prefs.edit().putBoolean("continuous_scroll", true).apply()',
         "Persist continuous scrolling ON", 1, 1),
    ])

    ui = (repo/FILES["ui"]).read_text(encoding="utf-8")
    exs = ex.read_text(encoding="utf-8")
    settings = (repo/FILES["extract_settings"]).read_text(encoding="utf-8")
    checks = {
        "rtl_double_reverse_removed": "entries.reversed().forEach" not in ui,
        "extraction_wait_5s": "awaitRuntimeService(5_000L)" in exs and "awaitWhatsAppRoot(liveAccessibility, targetPackage, 5_000L)" in exs,
        "deep_newest_accessibility": "totalNew += seekNewestBeforeDeep(group, prefs, seen)" in exs,
        "deep_newest_shizuku": "seekNewestBeforeDeepViaShizuku(group, prefs, packageName, tree, sequence, seen)" in exs,
        "new_only_top_to_bottom_accessibility": "svc.swipeTowardNewerMessages(timing.gestureDurationMs)" in exs,
        "new_only_top_to_bottom_shizuku": "shizukuUi.swipeListForward(tree, timing.gestureDurationMs.toInt())" in exs,
        "deep_bottom_to_top_accessibility": "svc.swipeTowardOlderMessages(timing.gestureDurationMs)" in exs,
        "deep_bottom_to_top_shizuku": "shizukuUi.swipeOlder(tree, timing.gestureDurationMs.toInt())" in exs,
        "capture_during_scroll": "captureBurst(group, seen, timing)" in exs,
        "checkpoint_present": "repository.saveCheckpoint(" in exs,
        "continuous_locked_on": "continuousScrollEnabled = true" in settings,
    }
    print("[VERIFY]", json.dumps(checks, ensure_ascii=False, indent=2))
    failed = [k for k,v in checks.items() if not v]
    if failed:
        die("Static verification failed: " + ", ".join(failed))

    if not args.no_build:
        gradlew = repo/"gradlew"
        if not gradlew.exists():
            die("gradlew missing")
        try:
            gradlew.chmod(gradlew.stat().st_mode | 0o111)
        except Exception:
            pass
        run(["./gradlew","testDebugUnitTest","--no-daemon","--console=plain"], repo)
        run(["./gradlew","clean","assembleDebug","--no-daemon","--console=plain"], repo)
        apks = sorted((repo/"app/build/outputs/apk/debug").glob("*.apk"))
        if not apks:
            die("Build finished but no debug APK found")
        print("[APK]")
        for apk in apks:
            print(" ", apk)

    print(f"[OK] {PATCH_VERSION} applied")
    print(f"[BACKUP] {backup}")

if __name__ == "__main__":
    main()
