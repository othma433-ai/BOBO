AL-thmany 3.4.2 — Corrective Patch v2 (Extraction Locked)
========================================================

هذا الملف يستبدل الحزمة السابقة قبل رفع التحديث.

الاستخراج أصبح مقيدًا بالخطة المتفق عليها:
- DEEP / ALL_CHATS / SMART:
  تثبيت أحدث رسالة أولًا، مع التقاط الروابط أثناء الوصول إليها، ثم المسح من أسفل إلى أعلى نحو الرسائل الأقدم.
- NEW_ONLY:
  الرجوع لتحديد أقدم unread/checkpoint ثم استخراج الرسائل الجديدة من أعلى إلى أسفل حتى أحدث رسالة.
- Continuous Adaptive Scrolling = ON دائمًا.
- التقاط الروابط قبل/أثناء/بعد الحركة.
- Fast End Verification.
- Checkpoint/Resume.
- Single-flight.
- لا إعادة تلقائية للقروبات COMPLETED ضمن قائمة الاستخراج التلقائية.
- نفس الاتجاه والمنطق لـ Accessibility وShizuku.
- إصلاح stale Accessibility root.
- زيادة انتظار تجهيز Accessibility للاستخراج إلى 5 ثوان بدل 1.5/1.8 ثانية.

ويشمل كذلك إصلاحات:
RTL + Scan + Publish runtime.

الاستخدام داخل Codespace:
python3 apply_althmany_342_patch_v2.py --repo /workspaces/BOBO

بعد التطبيق يشغل تلقائيًا:
./gradlew testDebugUnitTest
./gradlew clean assembleDebug

إذا فشل أي Build فلن يعلن نجاح التحديث.
